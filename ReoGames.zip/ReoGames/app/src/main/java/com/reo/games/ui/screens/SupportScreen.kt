package com.reo.games.ui.screens

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.SupportConfig
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors

private val HeartColor = Color(0xFFFF5C7A)

/**
 * صفحة دعم المطوّر. طوعي بالكامل، ولا علاقة له بالإعلانات (لا نربط التبرع بمشاهدة أو نقر أي إعلان).
 * الروابط تأتي من SupportConfig فقط.
 */
@Composable
fun SupportScreen(onBack: () -> Unit) {
    val c = LocalReoColors.current
    val context = LocalContext.current
    val donationUrl = SupportConfig.donationUrl
    val githubUrl = SupportConfig.githubUrl

    ReoScreen(title = "Support the Developer", onBack = onBack) {
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(18.dp))

            Box(
                Modifier.size(92.dp).clip(CircleShape).background(HeartColor.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Favorite, contentDescription = null, tint = HeartColor, modifier = Modifier.size(48.dp))
            }

            Text(
                "Support the Developer",
                color = c.textPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
            Text(
                "Thank you for using Reo Games! ❤️",
                color = c.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center
            )
            Text(
                "Reo Games is built and maintained by one developer. If you enjoy it, voluntary support helps fund " +
                    "development, maintenance and future features. It is completely optional: every feature stays " +
                    "available whether or not you donate.",
                color = c.textDim, fontSize = 14.sp, lineHeight = 21.sp, textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(4.dp))

            Button(
                onClick = { donationUrl?.let { openLink(context, it) } },
                enabled = donationUrl != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = HeartColor, contentColor = Color.White)
            ) {
                Icon(Icons.Rounded.Favorite, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(8.dp))
                Text("Support the Developer", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            if (donationUrl == null) {
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface.copy(alpha = 0.92f)).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Donations aren't available yet", color = c.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "There's no donation page set up for now. Thanks for thinking of it — it may come in a future update. " +
                            "Just using the app already means a lot.",
                        color = c.textDim, fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            } else {
                Text(
                    "Opens the developer's donation page in your browser.",
                    color = c.textDim, fontSize = 12.sp, textAlign = TextAlign.Center
                )
            }

            if (githubUrl != null) {
                OutlinedButton(
                    onClick = { openLink(context, githubUrl) },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Rounded.Code, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(8.dp))
                    Text("View the project on GitHub", fontSize = 15.sp)
                }
            }

            Spacer(Modifier.height(16.dp).navigationBarsPadding())
        }
    }
}

/** يفتح رابطاً في المتصفح، ويعالج غياب المتصفح دون انهيار. */
internal fun openLink(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No browser found to open this link.", Toast.LENGTH_SHORT).show()
    }
}
