package com.reo.games.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.reo.games.data.settings.AppSettings
import com.reo.games.ui.components.CardModel
import com.reo.games.ui.components.GameCard
import com.reo.games.ui.components.ReoBackground
import com.reo.games.ui.theme.LocalReoColors

private val sample = listOf(
    CardModel(-1, "Elden Ring", 2022, null, 62, "Playing"),
    CardModel(-2, "Cyberpunk 2077", 2020, null, null, "Backlog"),
    CardModel(-3, "God of War Ragnarök", 2022, null, 30, "Playing"),
    CardModel(-4, "Hollow Knight", 2017, null, null, "Completed"),
    CardModel(-5, "Red Dead Redemption 2", 2018, null, null, "Played"),
    CardModel(-6, "Celeste", 2018, null, 100, "Completed"),
    CardModel(-7, "Marvel's Spider-Man Remastered", 2022, null, null, "Dropped"),
    CardModel(-8, "Portal 2", 2011, null, null, "Played"),
    CardModel(-9, "Doom Eternal", 2020, null, 45, "Playing"),
    CardModel(-10, "Hades", 2020, null, null, "Completed")
)

/**
 * معاينة حية: تستخدم نفس مكوّن GameCard ونفس الخلفية والإعدادات الفعلية،
 * لذلك أي تغيير يظهر هنا وفي المكتبة في الوقت نفسه.
 */
@Composable
fun LayoutPreview(s: AppSettings, modifier: Modifier = Modifier) {
    val c = LocalReoColors.current
    val shape = RoundedCornerShape(16.dp)
    val rows = 2
    Box(modifier.fillMaxWidth().clip(shape).border(1.dp, c.outline, shape)) {
        ReoBackground(s, modifier = Modifier.matchParentSize()) {}
        Column(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(s.vSpacing.dp)
        ) {
            repeat(rows) { r ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(s.hSpacing.dp)) {
                    repeat(s.columns) { col ->
                        val item = sample[(r * s.columns + col) % sample.size]
                        GameCard(
                            model = item.copy(
                                progress = if (s.showProgressPlaying) item.progress?.takeIf { item.badge == "Playing" } else null,
                                badge = if (s.showCategoryBadge) item.badge else null
                            ),
                            s = s,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
