package com.reo.games.data.net

import retrofit2.http.GET
import retrofit2.http.Query

/** واجهة متجر Steam العامة: لا مفتاح ولا حساب. غير رسمية وقد تتغير. ألعاب PC فقط. */
interface SteamApi {
    @GET("api/storesearch/")
    suspend fun search(
        @Query("term") term: String,
        @Query("l") lang: String = "english",
        @Query("cc") country: String = "us"
    ): SteamSearchResponse

    @GET("api/appdetails")
    suspend fun details(
        @Query("appids") appId: Int,
        @Query("l") lang: String = "english"
    ): Map<String, SteamEnvelope>
}
