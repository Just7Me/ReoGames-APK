# قواعد R8 (غير مفعّلة في النسخة التجريبية)
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
