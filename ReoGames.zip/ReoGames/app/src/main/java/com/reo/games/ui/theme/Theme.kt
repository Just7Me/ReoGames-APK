package com.reo.games.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.ThemeMode
import com.reo.games.data.settings.ThemePreset

/** ألوان التطبيق الموحّدة؛ تتغير كلها عند تغيير الثيم أو لون التمييز. */
@Immutable
data class ReoColors(
    val isDark: Boolean,
    val accent: Color,
    val onAccent: Color,
    val bgBase: Color,       // الخلفية الافتراضية (الأعمق)
    val bgTint: Color,       // لون التدرج الافتراضي (كحلي/بنفسجي… حسب الثيم)
    val surface: Color,
    val surfaceHigh: Color,
    val textPrimary: Color,
    val textDim: Color,
    val outline: Color
)

val LocalReoColors = staticCompositionLocalOf<ReoColors> { error("ReoColors not provided") }

private data class PresetSpec(val accent: Long, val tint: Long)

private fun presetSpec(p: ThemePreset): PresetSpec = when (p) {
    ThemePreset.BLUE_NEON -> PresetSpec(0xFF2F8CFF, 0xFF0B1B3A)
    ThemePreset.PURPLE_NEON -> PresetSpec(0xFFA55BFF, 0xFF1A0F33)
    ThemePreset.RED_GAMING -> PresetSpec(0xFFFF3B4E, 0xFF2A0C12)
    ThemePreset.GREEN_GAMING -> PresetSpec(0xFF2EE67A, 0xFF08241A)
    ThemePreset.CYBERPUNK -> PresetSpec(0xFFFF2A6D, 0xFF1B0B2E)
    ThemePreset.MONOCHROME -> PresetSpec(0xFFE6E6E6, 0xFF1A1A1A)
    ThemePreset.MINIMAL_DARK -> PresetSpec(0xFF8FA3BF, 0xFF16181D)
    ThemePreset.CUSTOM -> PresetSpec(0xFF2F8CFF, 0xFF0B1B3A)
}

fun accentOf(s: AppSettings): Color =
    if (s.themePreset == ThemePreset.CUSTOM) Color(s.customAccent) else Color(presetSpec(s.themePreset).accent)

fun buildColors(s: AppSettings, systemDark: Boolean): ReoColors {
    val dark = when (s.themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDark
    }
    val accent = accentOf(s)
    val tint = if (s.themePreset == ThemePreset.CUSTOM) {
        // تدرج مشتق من لون التمييز المخصص
        Color(
            red = accent.red * 0.12f + 0.02f,
            green = accent.green * 0.12f + 0.03f,
            blue = accent.blue * 0.12f + 0.06f
        )
    } else Color(presetSpec(s.themePreset).tint)
    val onAccent = if (accent.luminance() > 0.5f) Color.Black else Color.White
    return if (dark) {
        ReoColors(
            isDark = true, accent = accent, onAccent = onAccent,
            bgBase = Color(0xFF05070D), bgTint = tint,
            surface = Color(0xFF0E1424), surfaceHigh = Color(0xFF172036),
            textPrimary = Color(0xFFF2F5FB), textDim = Color(0xFF9AA6BF),
            outline = Color(0xFF26324D)
        )
    } else {
        ReoColors(
            isDark = false, accent = accent, onAccent = onAccent,
            bgBase = Color(0xFFF4F6FB), bgTint = Color(0xFFE3E9F7),
            surface = Color(0xFFFFFFFF), surfaceHigh = Color(0xFFE9EDF7),
            textPrimary = Color(0xFF10172A), textDim = Color(0xFF56627E),
            outline = Color(0xFFCBD3E6)
        )
    }
}

private val ReoTypography = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 13.5.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 10.5.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun ReoTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val colors = buildColors(settings, isSystemInDarkTheme())
    val scheme = if (colors.isDark) {
        darkColorScheme(
            primary = colors.accent, onPrimary = colors.onAccent,
            secondary = colors.accent, onSecondary = colors.onAccent,
            background = colors.bgBase, onBackground = colors.textPrimary,
            surface = colors.surface, onSurface = colors.textPrimary,
            surfaceVariant = colors.surfaceHigh, onSurfaceVariant = colors.textDim,
            outline = colors.outline, outlineVariant = colors.outline,
            surfaceContainer = colors.surface, surfaceContainerHigh = colors.surfaceHigh,
            surfaceContainerHighest = colors.surfaceHigh
        )
    } else {
        lightColorScheme(
            primary = colors.accent, onPrimary = colors.onAccent,
            secondary = colors.accent, onSecondary = colors.onAccent,
            background = colors.bgBase, onBackground = colors.textPrimary,
            surface = colors.surface, onSurface = colors.textPrimary,
            surfaceVariant = colors.surfaceHigh, onSurfaceVariant = colors.textDim,
            outline = colors.outline, outlineVariant = colors.outline,
            surfaceContainer = colors.surface, surfaceContainerHigh = colors.surfaceHigh,
            surfaceContainerHighest = colors.surfaceHigh
        )
    }
    CompositionLocalProvider(LocalReoColors provides colors) {
        MaterialTheme(colorScheme = scheme, typography = ReoTypography, content = content)
    }
}
