package com.reo.games.ui.components

import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.data.settings.AppSettings

/** يحوّل كيان اللعبة إلى نموذج عرض البطاقة وفق إعدادات المستخدم. */
fun GameEntity.toCardModel(s: AppSettings, forceBadge: Boolean = false): CardModel = CardModel(
    id = id,
    title = title,
    year = releaseYear,
    cover = coverModel,
    progress = if (s.showProgressPlaying && category == GameCategory.PLAYING.key) progress else null,
    badge = if (s.showCategoryBadge || forceBadge) categoryEnum.label else null
)
