package com.reo.games.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.reo.games.AppContainer
import com.reo.games.data.ImageStore
import com.reo.games.data.ImportMode
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.BgType
import com.reo.games.data.settings.SortOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class LibraryFilter(
    val query: String = "",
    val genre: String? = null,
    val platform: String? = null,
    val year: Int? = null,
    val category: GameCategory? = null,
    val sort: SortOrder? = null
) {
    val isActive get() = query.isNotBlank() || genre != null || platform != null || year != null || category != null
}

data class FilterOptions(
    val genres: List<String> = emptyList(),
    val platforms: List<String> = emptyList(),
    val years: List<Int> = emptyList()
)

fun sortGames(list: List<GameEntity>, order: SortOrder): List<GameEntity> = when (order) {
    SortOrder.TITLE_AZ -> list.sortedBy { it.title.lowercase() }
    SortOrder.TITLE_ZA -> list.sortedByDescending { it.title.lowercase() }
    SortOrder.RECENT -> list.sortedByDescending { it.dateAdded }
    SortOrder.OLDEST -> list.sortedBy { it.dateAdded }
    SortOrder.RELEASE -> list.sortedWith(
        compareByDescending<GameEntity> { it.releaseDate ?: it.releaseYear?.toString() }
            .thenBy { it.title.lowercase() }
    ).let { sorted ->
        // الألعاب بلا تاريخ إصدار تذهب للنهاية
        sorted.filter { it.releaseDate != null || it.releaseYear != null } +
            sorted.filter { it.releaseDate == null && it.releaseYear == null }
    }
    SortOrder.RATING -> list.sortedWith(
        compareByDescending<GameEntity> { it.personalRating ?: -1 }.thenBy { it.title.lowercase() }
    )
    SortOrder.PLAYTIME -> list.sortedWith(
        compareByDescending<GameEntity> { it.playtimeHours ?: -1.0 }.thenBy { it.title.lowercase() }
    )
}

private fun splitList(s: String?): List<String> =
    s?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }.orEmpty()

class MainViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.games
    private val settingsRepo = c.settings

    val settings: StateFlow<AppSettings?> =
        settingsRepo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** null حتى تُحمَّل المكتبة (لتفادي وميض شاشة "فارغة"). */
    val games: StateFlow<List<GameEntity>?> =
        repo.observeAll().map<List<GameEntity>, List<GameEntity>?> { it }
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _selected = MutableStateFlow(GameCategory.PLAYING)
    val selected: StateFlow<GameCategory> = _selected.asStateFlow()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch {
            val s = settingsRepo.settings.first()
            if (s.rememberCategory) _selected.value = GameCategory.fromKey(s.lastCategory)
            _ready.value = true
        }
    }

    val counts: StateFlow<Map<GameCategory, Int>> = games.map { list ->
        GameCategory.entries.associateWith { cat -> list?.count { it.category == cat.key } ?: 0 }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, GameCategory.entries.associateWith { 0 })

    val visible: StateFlow<List<GameEntity>> = combine(games, _selected, settings) { g, cat, s ->
        sortGames(g.orEmpty().filter { it.category == cat.key }, s?.defaultSort ?: SortOrder.RECENT)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun selectCategory(cat: GameCategory) {
        _selected.value = cat
        viewModelScope.launch {
            val s = settingsRepo.settings.first()
            if (s.rememberCategory) settingsRepo.update { it.copy(lastCategory = cat.key) }
        }
    }

    fun setSort(order: SortOrder) = updateSettings { it.copy(defaultSort = order) }

    // ---------------- بحث وتصفية المكتبة ----------------
    private val _filter = MutableStateFlow(LibraryFilter())
    val filter: StateFlow<LibraryFilter> = _filter.asStateFlow()

    fun setFilter(transform: (LibraryFilter) -> LibraryFilter) = _filter.update(transform)
    fun resetFilter() { _filter.value = LibraryFilter() }

    val filterOptions: StateFlow<FilterOptions> = games.map { list ->
        val l = list.orEmpty()
        FilterOptions(
            genres = l.flatMap { splitList(it.genres) }.distinct().sorted(),
            platforms = l.flatMap { splitList(it.platforms) }.distinct().sorted(),
            years = l.mapNotNull { it.releaseYear }.distinct().sortedDescending()
        )
    }.stateIn(viewModelScope, SharingStarted.Eagerly, FilterOptions())

    val searchResults: StateFlow<List<GameEntity>> = combine(games, _filter, settings) { g, f, s ->
        val q = f.query.trim().lowercase()
        val filtered = g.orEmpty().filter { game ->
            (q.isEmpty() || game.title.lowercase().contains(q)) &&
                (f.genre == null || splitList(game.genres).contains(f.genre)) &&
                (f.platform == null || splitList(game.platforms).contains(f.platform)) &&
                (f.year == null || game.releaseYear == f.year) &&
                (f.category == null || game.category == f.category.key)
        }
        sortGames(filtered, f.sort ?: s?.defaultSort ?: SortOrder.RECENT)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---------------- الألعاب ----------------
    fun observeGame(id: Long) = repo.observe(id)

    fun moveTo(id: Long, cat: GameCategory) = viewModelScope.launch {
        repo.moveTo(id, cat)
        _messages.tryEmit("Moved to ${cat.label}")
    }

    fun saveGame(game: GameEntity) = viewModelScope.launch { repo.update(game) }

    fun removeGame(game: GameEntity) = viewModelScope.launch {
        repo.remove(game)
        _messages.tryEmit("Removed \"${game.title}\" from your library")
    }

    fun toast(msg: String) { _messages.tryEmit(msg) }

    // ---------------- الإعدادات ----------------
    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { settingsRepo.update(transform) }
    }

    fun resetAppearance() = viewModelScope.launch {
        settingsRepo.resetAppearance()
        _messages.tryEmit("Appearance reset to defaults")
    }

    fun resetAll() = viewModelScope.launch {
        settingsRepo.resetAll()
        // يحذف الخلفية المخصصة المخزنة داخلياً، ولا يمس المكتبة
        withContext(Dispatchers.IO) { cleanWallpapers(keep = null) }
        _selected.value = GameCategory.PLAYING
        _messages.tryEmit("All settings reset. Your library is untouched.")
    }

    private fun cleanWallpapers(keep: File?) {
        val dir = appContext().filesDir
        dir.listFiles { f -> f.name.startsWith("wallpaper") }?.forEach { f ->
            if (keep == null || f.absolutePath != keep.absolutePath) runCatching { f.delete() }
        }
    }

    private fun appContext() = c.app

    /** ينسخ الصورة المختارة إلى مساحة التطبيق (لا حاجة لإذن URI دائم) ثم يفعّلها كخلفية. */
    fun setWallpaper(uri: Uri) = viewModelScope.launch {
        val ctx = appContext()
        val dest = File(ctx.filesDir, "wallpaper_${System.currentTimeMillis()}.jpg")
        val ok = withContext(Dispatchers.IO) { ImageStore.importUri(ctx, uri, dest, 1920) }
        if (ok) {
            withContext(Dispatchers.IO) { cleanWallpapers(keep = dest) }
            settingsRepo.update { it.copy(bgType = BgType.IMAGE, bgImagePath = dest.absolutePath) }
            _messages.tryEmit("Wallpaper applied")
        } else {
            _messages.tryEmit("Couldn't read that image")
        }
    }

    fun exportAppearance(uri: Uri) = viewModelScope.launch {
        val current = settingsRepo.settings.first()
        val text = settingsRepo.exportAppearanceJson(current)
        val ok = withContext(Dispatchers.IO) {
            runCatching {
                appContext().contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) } != null
            }.getOrDefault(false)
        }
        _messages.tryEmit(if (ok) "Appearance exported" else "Export failed")
    }

    fun importAppearance(uri: Uri) = viewModelScope.launch {
        val text = withContext(Dispatchers.IO) {
            runCatching {
                appContext().contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
            }.getOrNull()
        }
        val ok = text != null && settingsRepo.importAppearanceJson(text)
        _messages.tryEmit(if (ok) "Appearance imported" else "That isn't a valid appearance file")
    }

    // ---------------- النسخ الاحتياطي ----------------
    fun exportLibrary(uri: Uri) = viewModelScope.launch {
        c.backup.exportTo(uri)
            .onSuccess { _messages.tryEmit("Exported $it games") }
            .onFailure { _messages.tryEmit("Export failed: ${it.message}") }
    }

    fun importLibrary(uri: Uri, mode: ImportMode) = viewModelScope.launch {
        val r = c.backup.importFrom(uri, mode)
        _messages.tryEmit(
            r.error?.let { "Import failed: $it" }
                ?: "Imported ${r.added} games" +
                (if (r.skippedDuplicates > 0) ", skipped ${r.skippedDuplicates} duplicates" else "")
        )
    }

    // ---------------- مفتاح API ----------------
    private val _hasKey = MutableStateFlow(c.apiKeys.hasKey())
    val hasKey: StateFlow<Boolean> = _hasKey.asStateFlow()
    fun userKey(): String = c.apiKeys.userKey()
    fun saveKey(key: String) {
        c.apiKeys.setUserKey(key)
        _hasKey.value = c.apiKeys.hasKey()
        _messages.tryEmit(if (key.isBlank()) "API key cleared" else "API key saved")
    }
}

class ReoViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(MainViewModel::class.java) -> MainViewModel(c) as T
        modelClass.isAssignableFrom(AddGameViewModel::class.java) -> AddGameViewModel(c) as T
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    }
}
