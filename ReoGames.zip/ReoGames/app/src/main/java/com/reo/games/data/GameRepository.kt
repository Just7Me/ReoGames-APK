package com.reo.games.data

import android.content.Context
import android.net.Uri
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameDao
import com.reo.games.data.db.GameEntity
import com.reo.games.data.net.ApiKeyStore
import com.reo.games.data.net.RawgApi
import com.reo.games.data.net.RawgGameDetail
import com.reo.games.data.net.RawgGameSummary
import com.reo.games.data.net.RawgSearchResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.HttpException
import java.io.File
import java.io.IOException

sealed interface ApiResult<out T> {
    data class Success<T>(val data: T) : ApiResult<T>
    data object NoKey : ApiResult<Nothing>
    data object Offline : ApiResult<Nothing>
    data class Error(val message: String) : ApiResult<Nothing>
}

sealed interface AddResult {
    data class Added(val id: Long, val category: GameCategory) : AddResult
    data class Duplicate(val existing: GameEntity) : AddResult
}

class GameRepository(
    private val context: Context,
    private val dao: GameDao,
    private val api: RawgApi,
    private val keys: ApiKeyStore,
    private val http: OkHttpClient,
    private val isOnline: () -> Boolean
) {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun observeAll(): Flow<List<GameEntity>> = dao.observeAll()
    fun observe(id: Long): Flow<GameEntity?> = dao.observeById(id)
    suspend fun get(id: Long): GameEntity? = dao.getById(id)
    suspend fun findDuplicate(rawgId: Int?, title: String): GameEntity? =
        (rawgId?.let { dao.getByRawgId(it) }) ?: dao.getByTitle(title.trim())
    suspend fun getAll(): List<GameEntity> = dao.getAll()

    // ---------------- الشبكة ----------------

    private suspend fun <T> call(block: suspend (key: String) -> T): ApiResult<T> {
        val key = keys.get()
        if (key.isEmpty()) return ApiResult.NoKey
        return try {
            ApiResult.Success(withContext(Dispatchers.IO) { block(key) })
        } catch (e: HttpException) {
            if (e.code() == 504 && !isOnline()) return ApiResult.Offline
            when (e.code()) {
                401, 403 -> ApiResult.Error("The RAWG API key was rejected. Check the key in Settings.")
                429 -> ApiResult.Error("RAWG rate limit reached. Try again in a moment.")
                else -> ApiResult.Error("Server error (${e.code()}). Try again later.")
            }
        } catch (e: IOException) {
            if (isOnline()) ApiResult.Error("Couldn't reach the game database.") else ApiResult.Offline
        } catch (e: Exception) {
            ApiResult.Error("Something went wrong reading the response.")
        }
    }

    suspend fun search(query: String, page: Int): ApiResult<RawgSearchResponse> =
        call { key -> api.search(key = key, query = query.trim(), page = page) }

    suspend fun details(rawgId: Int): ApiResult<RawgGameDetail> =
        call { key -> api.details(rawgId, key) }

    // ---------------- الإضافة ----------------

    /** يبني كيان لعبة من نتيجة البحث وتفاصيلها (التفاصيل قد تكون null عند الفشل/عدم الاتصال). */
    fun buildEntity(
        summary: RawgGameSummary,
        detail: RawgGameDetail?,
        category: GameCategory
    ): GameEntity {
        val released = detail?.released ?: summary.released
        return GameEntity(
            rawgId = summary.id,
            title = (detail?.name ?: summary.name ?: "Untitled").trim(),
            coverUrl = detail?.backgroundImage ?: summary.backgroundImage,
            description = detail?.descriptionRaw?.trim()?.ifEmpty { null },
            releaseDate = released,
            releaseYear = released?.take(4)?.toIntOrNull(),
            developers = detail?.developers?.mapNotNull { it.name }?.joinToString(", ")?.ifEmpty { null },
            publishers = detail?.publishers?.mapNotNull { it.name }?.joinToString(", ")?.ifEmpty { null },
            platforms = (detail?.platforms ?: summary.platforms)
                ?.mapNotNull { it.platform?.name }?.joinToString(", ")?.ifEmpty { null },
            genres = (detail?.genres ?: summary.genres)
                ?.mapNotNull { it.name }?.joinToString(", ")?.ifEmpty { null },
            rating = (detail?.rating ?: summary.rating)?.takeIf { it > 0.0 },
            website = detail?.website?.trim()?.ifEmpty { null },
            category = category.key
        )
    }

    suspend fun add(game: GameEntity): AddResult {
        findDuplicate(game.rawgId, game.title)?.let { return AddResult.Duplicate(it) }
        val id = dao.insert(game.copy(id = 0, dateAdded = System.currentTimeMillis(), sortIndex = System.currentTimeMillis()))
        if (id == -1L) {
            findDuplicate(game.rawgId, game.title)?.let { return AddResult.Duplicate(it) }
        }
        cacheCoverInBackground(id, game)
        return AddResult.Added(id, game.categoryEnum)
    }

    /** يحفظ نسخة محلية من الغلاف ليعمل التطبيق دون إنترنت. لا يؤثر فشلها على الإضافة. */
    fun cacheCoverInBackground(id: Long, game: GameEntity) {
        val url = game.coverUrl ?: return
        if (game.localCoverPath != null) return
        appScope.launch {
            val file = File(ImageStore.coversDir(context), "game_$id.img")
            if (ImageStore.downloadTo(http, url, file)) {
                dao.getById(id)?.let { dao.update(it.copy(localCoverPath = file.absolutePath)) }
            }
        }
    }

    /** إضافة يدوية (لعبة غير موجودة في قاعدة البيانات) مع صورة اختيارية من الهاتف. */
    suspend fun addManual(title: String, coverUri: Uri?, category: GameCategory, year: Int?): AddResult {
        val clean = title.trim()
        findDuplicate(null, clean)?.let { return AddResult.Duplicate(it) }
        val id = dao.insert(
            GameEntity(title = clean, releaseYear = year, category = category.key)
        )
        if (coverUri != null) withContext(Dispatchers.IO) {
            val f = File(ImageStore.coversDir(context), "manual_$id.jpg")
            if (ImageStore.importUri(context, coverUri, f, 700)) {
                dao.getById(id)?.let { dao.update(it.copy(localCoverPath = f.absolutePath)) }
            }
        }
        return AddResult.Added(id, category)
    }

    // ---------------- التعديل والحذف ----------------

    suspend fun update(game: GameEntity) = dao.update(game)

    suspend fun moveTo(id: Long, category: GameCategory) {
        val g = dao.getById(id) ?: return
        val completedAt = when {
            category == GameCategory.COMPLETED && g.dateCompleted == null -> System.currentTimeMillis()
            else -> g.dateCompleted
        }
        dao.update(
            g.copy(
                category = category.key,
                sortIndex = System.currentTimeMillis(),
                dateCompleted = completedAt
            )
        )
    }

    suspend fun remove(game: GameEntity) {
        dao.delete(game)
        game.localCoverPath?.let { withContext(Dispatchers.IO) { runCatching { File(it).delete() } } }
    }
}
