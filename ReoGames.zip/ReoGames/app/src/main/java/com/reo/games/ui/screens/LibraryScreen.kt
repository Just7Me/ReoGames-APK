package com.reo.games.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import com.reo.games.ads.LocalBannerShown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SortByAlpha
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.CategoryStyle
import com.reo.games.data.settings.SortOrder
import com.reo.games.ui.MainViewModel
import com.reo.games.ui.components.GameCard
import com.reo.games.ui.components.toCardModel
import com.reo.games.ui.sortGames
import com.reo.games.ui.theme.LocalReoColors

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    vm: MainViewModel,
    s: AppSettings,
    onOpenGame: (Long) -> Unit,
    onAdd: (GameCategory) -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onSupport: () -> Unit
) {
    val games by vm.games.collectAsState()
    val selected by vm.selected.collectAsState()
    val counts by vm.counts.collectAsState()
    val haptic = LocalHapticFeedback.current

    val cats = GameCategory.entries
    val pagerState = rememberPagerState(initialPage = cats.indexOf(selected)) { cats.size }

    // مزامنة الشريط العلوي مع السحب الأفقي بين الصفحات
    LaunchedEffect(selected) {
        val target = cats.indexOf(selected)
        if (pagerState.currentPage != target) {
            if (s.animations) pagerState.animateScrollToPage(target) else pagerState.scrollToPage(target)
        }
    }
    LaunchedEffect(pagerState.settledPage) {
        val cat = cats[pagerState.settledPage]
        if (cat != selected) vm.selectCategory(cat)
    }

    var sheetGame by remember { mutableStateOf<GameEntity?>(null) }
    var removeCandidate by remember { mutableStateOf<GameEntity?>(null) }

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.statusBars)) {
        ReoTopBar(s, onSearch = onSearch, onAdd = { onAdd(selected) }, onSettings = onSettings, onSupport = onSupport)
        CategoryBar(
            s = s,
            selected = selected,
            counts = counts,
            onSelect = {
                if (s.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                vm.selectCategory(it)
            },
            onSort = { vm.setSort(it) },
            onSearch = onSearch
        )

        if (games == null) {
            Box(Modifier.fillMaxSize())
        } else {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                key = { cats[it].key }
            ) { page ->
                val cat = cats[page]
                val list = remember(games, cat, s.defaultSort) {
                    sortGames(games.orEmpty().filter { it.category == cat.key }, s.defaultSort)
                }
                if (list.isEmpty()) {
                    EmptyState(cat, onAdd = { onAdd(cat) })
                } else {
                    GameGrid(
                        list = list,
                        s = s,
                        onOpen = onOpenGame,
                        onLongPress = { sheetGame = it }
                    )
                }
            }
        }
    }

    sheetGame?.let { g ->
        QuickActionsSheet(
            game = g,
            onDismiss = { sheetGame = null },
            onOpen = { sheetGame = null; onOpenGame(g.id) },
            onMove = { cat -> sheetGame = null; vm.moveTo(g.id, cat) },
            onRemove = {
                sheetGame = null
                if (s.confirmRemove) removeCandidate = g else vm.removeGame(g)
            }
        )
    }
    removeCandidate?.let { g ->
        ConfirmRemoveDialog(g.title, onDismiss = { removeCandidate = null }) {
            removeCandidate = null
            vm.removeGame(g)
        }
    }
}

@Composable
fun GameGrid(
    list: List<GameEntity>,
    s: AppSettings,
    onOpen: (Long) -> Unit,
    onLongPress: ((GameEntity) -> Unit)?,
    modifier: Modifier = Modifier
) {
    // عند ظهور شريط الإعلان يتولى هو حشوة شريط التنقل، فلا نكررها هنا
    val navBottom = if (LocalBannerShown.current) 0.dp
    else WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    LazyVerticalGrid(
        // أعمدة بوزن متساوٍ: لا يمكن أن يتجاوز أي عدد من الأعمدة (2–5) عرض الشاشة
        columns = GridCells.Fixed(s.columns),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 24.dp + navBottom),
        horizontalArrangement = Arrangement.spacedBy(s.hSpacing.dp),
        verticalArrangement = Arrangement.spacedBy(s.vSpacing.dp)
    ) {
        items(list, key = { it.id }) { game ->
            GameCard(
                model = game.toCardModel(s),
                s = s,
                onClick = { onOpen(game.id) },
                onLongClick = onLongPress?.let { f -> { f(game) } }
            )
        }
    }
}

// ------------------------------------------------------------------ الشريط العلوي

@Composable
private fun ReoTopBar(s: AppSettings, onSearch: () -> Unit, onAdd: () -> Unit, onSettings: () -> Unit, onSupport: () -> Unit) {
    val c = LocalReoColors.current
    val h = if (s.toolbarCompact) 46.dp else 62.dp
    Row(
        Modifier.fillMaxWidth().height(h).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.SportsEsports, null, tint = c.accent, modifier = Modifier.size(if (s.toolbarCompact) 24.dp else 28.dp))
        if (s.showAppName) {
            Spacer(Modifier.width(8.dp))
            Text(
                "Reo Games",
                color = c.textPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = if (s.toolbarCompact) 18.sp else 21.sp,
                letterSpacing = 0.3.sp,
                // يأخذ المساحة المتبقية (بدل الـ Spacer) ويُقتطع بنقاط إن ضاق العرض، فلا تتزاحم الأزرار
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        } else {
            Spacer(Modifier.weight(1f))
        }
        SupportCoffeeButton(onClick = onSupport)
        if (s.showSearchShortcut) {
            IconButton(onClick = onSearch) { Icon(Icons.Rounded.Search, "Search library", tint = c.textPrimary) }
        }
        if (s.iconButtons) {
            IconButton(onClick = onAdd) { Icon(Icons.Rounded.Add, "Add game", tint = c.accent) }
            IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Settings", tint = c.textPrimary) }
        } else {
            Button(
                onClick = onAdd,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                modifier = Modifier.height(32.dp)
            ) { Text("Add", fontSize = 13.sp) }
            TextButton(onClick = onSettings) { Text("Settings", color = c.textPrimary, fontSize = 13.sp) }
        }
    }
}

// ------------------------------------------------------------------ شريط الفئات

@Composable
private fun CategoryBar(
    s: AppSettings,
    selected: GameCategory,
    counts: Map<GameCategory, Int>,
    onSelect: (GameCategory) -> Unit,
    onSort: (SortOrder) -> Unit,
    onSearch: () -> Unit
) {
    val c = LocalReoColors.current
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        LazyRow(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(s.categorySpacing.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(GameCategory.entries.toList(), key = { it.key }) { cat ->
                CategoryChip(
                    cat = cat,
                    count = if (s.showCounts) counts[cat] ?: 0 else null,
                    selected = cat == selected,
                    style = s.categoryStyle,
                    animate = s.animations,
                    onClick = { onSelect(cat) }
                )
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Rounded.SortByAlpha, "Sort", tint = c.textDim)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (!s.showSearchShortcut) {
                    // بديل الوصول للبحث عند إخفاء اختصاره
                    DropdownMenuItem(
                        text = { Text("Search library…") },
                        leadingIcon = { Icon(Icons.Rounded.Search, null) },
                        onClick = { menu = false; onSearch() }
                    )
                }
                SortOrder.entries.forEach { order ->
                    DropdownMenuItem(
                        text = { Text(order.label) },
                        trailingIcon = { if (order == s.defaultSort) Icon(Icons.Rounded.Check, null, tint = c.accent) },
                        onClick = { menu = false; onSort(order) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryChip(
    cat: GameCategory,
    count: Int?,
    selected: Boolean,
    style: CategoryStyle,
    animate: Boolean,
    onClick: () -> Unit
) {
    val c = LocalReoColors.current
    val spec = tween<Color>(if (animate) 220 else 0)
    val textColor by animateColorAsState(
        when {
            selected && style == CategoryStyle.PILL -> c.onAccent
            selected -> c.accent
            else -> c.textDim
        }, spec, label = "chipText"
    )
    val bg by animateColorAsState(
        if (selected && style == CategoryStyle.PILL) c.accent
        else if (style == CategoryStyle.PILL) c.surface.copy(alpha = 0.7f) else Color.Transparent,
        spec, label = "chipBg"
    )
    val underline by animateColorAsState(
        if (selected && style == CategoryStyle.UNDERLINE) c.accent else Color.Transparent,
        spec, label = "chipUnderline"
    )

    val shape = if (style == CategoryStyle.PILL) RoundedCornerShape(50) else RoundedCornerShape(6.dp)
    Column(
        Modifier
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(
                horizontal = if (style == CategoryStyle.PILL) 14.dp else 6.dp,
                vertical = if (style == CategoryStyle.PILL) 7.dp else 5.dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                cat.label,
                color = textColor,
                fontSize = 14.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1
            )
            if (count != null) {
                Spacer(Modifier.width(6.dp))
                Text(
                    count.toString(),
                    color = if (selected && style == CategoryStyle.PILL) c.onAccent.copy(alpha = 0.85f) else textColor.copy(alpha = 0.75f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        if (style == CategoryStyle.UNDERLINE) {
            Spacer(Modifier.height(4.dp))
            Box(Modifier.height(2.5.dp).fillMaxWidth().clip(CircleShape).background(underline))
        }
    }
}

// ------------------------------------------------------------------ حالة فارغة

@Composable
private fun EmptyState(cat: GameCategory, onAdd: () -> Unit) {
    val c = LocalReoColors.current
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(c.accent.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.SportsEsports, null, tint = c.accent, modifier = Modifier.size(42.dp)) }
        Spacer(Modifier.height(18.dp))
        Text("Nothing in ${cat.label} yet", color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            emptyHint(cat),
            color = c.textDim,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAdd) {
            Icon(Icons.Rounded.Add, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Add Game")
        }
    }
}

private fun emptyHint(cat: GameCategory) = when (cat) {
    GameCategory.PLAYING -> "Games you're currently playing will show up here."
    GameCategory.COMPLETED -> "Finished a game? Add it here to build your trophy shelf."
    GameCategory.BACKLOG -> "Owned but not started — keep your backlog organized."
    GameCategory.DROPPED -> "Games you started and stopped end up here."
    GameCategory.PLAYED -> "Played but not finished and not playing now."
}

// ------------------------------------------------------------------ نافذة الإجراءات السريعة

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickActionsSheet(
    game: GameEntity,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onMove: (GameCategory) -> Unit,
    onRemove: () -> Unit
) {
    val c = LocalReoColors.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = c.surface) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(
                game.title,
                color = c.textPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
            )
            Text(
                "Move to",
                color = c.textDim,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
            )
            GameCategory.entries.forEach { cat ->
                val current = cat.key == game.category
                ListItem(
                    headlineContent = { Text(cat.label, color = if (current) c.accent else c.textPrimary) },
                    trailingContent = { if (current) Icon(Icons.Rounded.Check, null, tint = c.accent) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    modifier = Modifier.clickable(enabled = !current) { onMove(cat) }
                )
            }
            ListItem(
                headlineContent = { Text("Open details", color = c.textPrimary) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable(onClick = onOpen)
            )
            ListItem(
                headlineContent = { Text("Remove from library", color = Color(0xFFFF5D6C)) },
                leadingContent = { Icon(Icons.Rounded.Delete, null, tint = Color(0xFFFF5D6C)) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable(onClick = onRemove)
            )
        }
    }
}

@Composable
fun ConfirmRemoveDialog(title: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Remove game?") },
        text = {
            Text(
                "\"$title\" will be removed from your library, along with your notes and progress. " +
                    "It stays in the online database — you can add it again any time."
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Remove", color = Color(0xFFFF5D6C)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** زر ☕ متوسط الحجم في الشريط العلوي يفتح صفحة «Support the Developer» (دعم طوعي). */
@Composable
private fun SupportCoffeeButton(onClick: () -> Unit) {
    Box(
        Modifier
            .padding(horizontal = 4.dp)
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFFC8935A).copy(alpha = 0.22f))
            .clickable(onClickLabel = "Support the Developer", onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("☕", fontSize = 20.sp)
    }
}
