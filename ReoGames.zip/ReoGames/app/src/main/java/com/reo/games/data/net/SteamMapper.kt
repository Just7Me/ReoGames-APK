package com.reo.games.data.net

import android.text.Html
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * يحوّل بيانات Steam إلى نماذج RAWG المستخدمة في بقية التطبيق، فلا تحتاج الشاشات لمعرفة المصدر.
 * معرّف ألعاب Steam يُخزَّن سالباً (‑appId) كي لا يتصادم مع معرّفات RAWG في الحقل rawgId.
 */
object SteamMapper {
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true; isLenient = true }

    fun isSteamId(id: Int) = id < 0

    /** غلاف عمودي (600×900) إن وُجد للعبة. */
    fun libraryCover(appId: Int) = "https://cdn.cloudflare.steamstatic.com/steam/apps/$appId/library_600x900.jpg"

    private fun platformList(p: SteamPlatforms?): List<PlatformWrapper> = buildList {
        if (p?.windows == true) add(PlatformWrapper(NamedItem("PC")))
        if (p?.mac == true) add(PlatformWrapper(NamedItem("macOS")))
        if (p?.linux == true) add(PlatformWrapper(NamedItem("Linux")))
    }

    /** Metacritic من 100 إلى مقياس 5 نجوم المستخدم في التطبيق. */
    private fun toFiveStars(score: Double?): Double? = score?.div(20.0)?.takeIf { it > 0.0 }

    fun toSummary(item: SteamSearchItem): RawgGameSummary? {
        val name = item.name?.trim()?.takeIf { it.isNotEmpty() } ?: return null
        if (item.id <= 0) return null
        val meta = (item.metascore as? JsonPrimitive)?.contentOrNull?.toDoubleOrNull()
        return RawgGameSummary(
            id = -item.id,
            name = name,
            released = null, // البحث لا يعيد التاريخ؛ يأتي في التفاصيل
            backgroundImage = libraryCover(item.id),
            rating = toFiveStars(meta),
            platforms = platformList(item.platforms).ifEmpty { null },
            genres = null
        )
    }

    /** يقرأ حقل data (قد يكون كائناً أو مصفوفة فارغة عند الفشل). */
    fun parseData(element: JsonElement?): SteamAppData? {
        val obj = element as? JsonObject ?: return null
        return try {
            json.decodeFromJsonElement(SteamAppData.serializer(), obj)
        } catch (e: Exception) {
            null
        }
    }

    fun toDetail(appId: Int, d: SteamAppData, cover: String?): RawgGameDetail = RawgGameDetail(
        id = -appId,
        name = d.name,
        descriptionRaw = d.shortDescription?.let { plainText(it) }?.takeIf { it.isNotEmpty() },
        released = normalizeDate(d.releaseDate?.date),
        backgroundImage = cover ?: d.headerImage,
        rating = toFiveStars(d.metacritic?.score?.toDouble()),
        website = d.website?.takeIf { it.startsWith("http") },
        developers = d.developers?.map { NamedItem(it) },
        publishers = d.publishers?.map { NamedItem(it) },
        platforms = platformList(d.platforms).ifEmpty { null },
        genres = d.genres?.map { NamedItem(it.description) }
    )

    private fun plainText(html: String): String =
        Html.fromHtml(html, Html.FROM_HTML_MODE_COMPACT).toString().trim()

    private val datePatterns = listOf("d MMM, yyyy", "MMM d, yyyy", "d MMMM, yyyy", "MMMM d, yyyy")
        .map { DateTimeFormatter.ofPattern(it, Locale.ENGLISH) }

    /** يعيد تاريخاً بصيغة yyyy-MM-dd إن أمكن، وإلا السنة فقط، وإلا null (مثل "Coming soon"). */
    fun normalizeDate(raw: String?): String? {
        val s = raw?.trim().orEmpty()
        if (s.isEmpty()) return null
        for (f in datePatterns) {
            try {
                return LocalDate.parse(s, f).toString()
            } catch (e: Exception) {
                // جرّب الصيغة التالية
            }
        }
        return Regex("(19|20)\\d{2}").find(s)?.value
    }
}
