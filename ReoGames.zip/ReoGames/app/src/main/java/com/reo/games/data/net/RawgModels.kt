package com.reo.games.data.net

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class NamedItem(val name: String? = null)

@Serializable
data class PlatformWrapper(val platform: NamedItem? = null)

@Serializable
data class RawgSearchResponse(
    val count: Int = 0,
    val next: String? = null,
    val results: List<RawgGameSummary> = emptyList()
)

@Serializable
data class RawgGameSummary(
    val id: Int,
    val name: String? = null,
    val released: String? = null,
    @SerialName("background_image") val backgroundImage: String? = null,
    val rating: Double? = null,
    val platforms: List<PlatformWrapper>? = null,
    val genres: List<NamedItem>? = null
) {
    val year: Int? get() = released?.take(4)?.toIntOrNull()
    val platformNames: List<String> get() = platforms?.mapNotNull { it.platform?.name }.orEmpty()
}

@Serializable
data class RawgGameDetail(
    val id: Int,
    val name: String? = null,
    @SerialName("description_raw") val descriptionRaw: String? = null,
    val released: String? = null,
    @SerialName("background_image") val backgroundImage: String? = null,
    val rating: Double? = null,
    val website: String? = null,
    val developers: List<NamedItem>? = null,
    val publishers: List<NamedItem>? = null,
    val platforms: List<PlatformWrapper>? = null,
    val genres: List<NamedItem>? = null
)
