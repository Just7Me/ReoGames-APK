package com.reo.games.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM games")
    fun observeAll(): Flow<List<GameEntity>>

    @Query("SELECT * FROM games WHERE id = :id")
    fun observeById(id: Long): Flow<GameEntity?>

    @Query("SELECT * FROM games WHERE id = :id")
    suspend fun getById(id: Long): GameEntity?

    @Query("SELECT * FROM games WHERE rawgId = :rawgId LIMIT 1")
    suspend fun getByRawgId(rawgId: Int): GameEntity?

    @Query("SELECT * FROM games WHERE LOWER(title) = LOWER(:title) LIMIT 1")
    suspend fun getByTitle(title: String): GameEntity?

    @Query("SELECT * FROM games")
    suspend fun getAll(): List<GameEntity>

    /** يعيد -1 إذا كانت اللعبة موجودة (فهرس rawgId الفريد) بدل رمي استثناء. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(game: GameEntity): Long

    @Update
    suspend fun update(game: GameEntity)

    @Delete
    suspend fun delete(game: GameEntity)

    @Query("DELETE FROM games")
    suspend fun deleteAll()

    @Query("UPDATE games SET category = :category, sortIndex = :sortIndex WHERE id = :id")
    suspend fun setCategory(id: Long, category: String, sortIndex: Long)

    @Query("UPDATE games SET sortIndex = :sortIndex WHERE id = :id")
    suspend fun setSortIndex(id: Long, sortIndex: Long)
}
