package com.reo.games.ui.screens

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.AspectMode
import com.reo.games.data.settings.BgScale
import com.reo.games.data.settings.BgTexture
import com.reo.games.data.settings.BgType
import com.reo.games.data.settings.GradientDir
import com.reo.games.ui.MainViewModel
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors

@Composable
fun SettingsScreen(vm: MainViewModel, s: AppSettings, onBack: () -> Unit) {
    ReoScreen(title = "Settings", onBack = onBack) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Spacer(Modifier.height(2.dp))
            LayoutSection(vm, s)
            BackgroundSection(vm, s)
            ThemeSection(vm, s)
            TopBarSection(vm, s)
            InteractionSection(vm, s)
            DataSection(vm)
            ManagementSection(vm, s)
            Spacer(Modifier.height(16.dp).navigationBarsPadding())
        }
    }
}

// ------------------------------------------------------------------ تخطيط المكتبة + معاينة حية

@Composable
private fun LayoutSection(vm: MainViewModel, s: AppSettings) {
    val u = vm::updateSettings
    SettingsSection("Library layout") {
        SubTitle("Live preview")
        LayoutPreview(s)

        SubTitle("Games per row")
        ChoiceChips(
            options = listOf(2, 3, 4, 5).map { it to "$it" },
            selected = s.columns,
            onSelect = { n -> u { it.copy(columns = n) } }
        )

        SubTitle("Cover size")
        val presets = listOf(0.72f to "Small", 0.86f to "Medium", 1f to "Large")
        val matched = presets.firstOrNull { kotlin.math.abs(it.first - s.coverScale) < 0.02f }?.first
        ChoiceChips(
            options = presets,
            selected = matched ?: -1f,
            onSelect = { v -> u { it.copy(coverScale = v) } }
        )
        SliderRow("Fine-tune size", s.coverScale, 0.6f..1f, "${(s.coverScale * 100).toInt()}%") { v -> u { it.copy(coverScale = v) } }

        SubTitle("Cover aspect ratio")
        ChoiceChips(
            options = AspectMode.entries.map { it to it.label },
            selected = s.aspect,
            onSelect = { a -> u { it.copy(aspect = a) } }
        )

        SubTitle("Card appearance")
        SliderRow("Rounded corners", s.cornerRadius, 0f..28f, "${s.cornerRadius.toInt()} dp") { v -> u { it.copy(cornerRadius = v) } }
        SliderRow("Card background opacity", s.cardOpacity, 0.2f..1f, "${(s.cardOpacity * 100).toInt()}%") { v -> u { it.copy(cardOpacity = v) } }
        SwitchRow("Border", s.cardBorder) { v -> u { it.copy(cardBorder = v) } }
        SwitchRow("Shadow", s.cardShadow) { v -> u { it.copy(cardShadow = v) } }
        SwitchRow("Glow effect", s.cardGlow) { v -> u { it.copy(cardGlow = v) } }
        SwitchRow("Compact layout", s.compact, hint = "Title overlaps the cover") { v -> u { it.copy(compact = v) } }

        SubTitle("Titles")
        SwitchRow("Show titles", s.showTitle) { v -> u { it.copy(showTitle = v) } }
        SwitchRow("Show release year", s.showYear, enabled = s.showTitle) { v -> u { it.copy(showYear = v) } }
        SubTitle("Title lines")
        ChoiceChips(listOf(1 to "One line", 2 to "Two lines"), s.titleLines) { n -> u { it.copy(titleLines = n) } }
        SliderRow("Title text size", s.titleSize, 9f..16f, "${"%.0f".format(s.titleSize)} sp") { v -> u { it.copy(titleSize = v) } }
        SubTitle("Title alignment")
        ChoiceChips(listOf(false to "Left", true to "Centered"), s.titleCenter) { b -> u { it.copy(titleCenter = b) } }

        SubTitle("Spacing")
        SliderRow("Horizontal spacing", s.hSpacing, 0f..24f, "${s.hSpacing.toInt()} dp") { v -> u { it.copy(hSpacing = v) } }
        SliderRow("Vertical spacing", s.vSpacing, 0f..32f, "${s.vSpacing.toInt()} dp") { v -> u { it.copy(vSpacing = v) } }
        SliderRow("Cover ↔ title gap", s.titleGap, 0f..14f, "${s.titleGap.toInt()} dp") { v -> u { it.copy(titleGap = v) } }
    }
}

// ------------------------------------------------------------------ الخلفية

@Composable
private fun BackgroundSection(vm: MainViewModel, s: AppSettings) {
    val c = LocalReoColors.current
    val u = vm::updateSettings
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setWallpaper(uri)
    }
    SettingsSection("Library background") {
        ChoiceChips(
            options = listOf(
                BgType.DEFAULT to "Default dark",
                BgType.BLACK to "Pure black",
                BgType.NAVY to "Dark navy",
                BgType.SOLID to "Solid color",
                BgType.GRADIENT to "Gradient",
                BgType.IMAGE to "Image"
            ),
            selected = s.bgType,
            onSelect = { t ->
                if (t == BgType.IMAGE && s.bgImagePath.isEmpty()) {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                } else u { it.copy(bgType = t) }
            }
        )

        when (s.bgType) {
            BgType.SOLID -> ColorRow("Background color", s.bgSolid) { col -> u { it.copy(bgSolid = col) } }
            BgType.GRADIENT -> {
                ColorRow("Start color", s.bgGradStart) { col -> u { it.copy(bgGradStart = col) } }
                ColorRow("End color", s.bgGradEnd) { col -> u { it.copy(bgGradEnd = col) } }
                SubTitle("Direction")
                ChoiceChips(
                    listOf(
                        GradientDir.TOP_BOTTOM to "Top → bottom",
                        GradientDir.BOTTOM_TOP to "Bottom → top",
                        GradientDir.LEFT_RIGHT to "Left → right",
                        GradientDir.RIGHT_LEFT to "Right → left",
                        GradientDir.DIAG_DOWN to "Diagonal ↘",
                        GradientDir.DIAG_UP to "Diagonal ↗"
                    ),
                    s.bgGradDir
                ) { d -> u { it.copy(bgGradDir = d) } }
            }
            BgType.IMAGE -> {
                Button(
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (s.bgImagePath.isEmpty()) "Choose wallpaper from gallery" else "Change wallpaper") }
                SubTitle("Scaling")
                ChoiceChips(
                    listOf(BgScale.COVER to "Cover (fill)", BgScale.FIT to "Fit (no crop)"),
                    s.bgScale
                ) { b -> u { it.copy(bgScale = b) } }
                SliderRow("Brightness", s.bgBrightness, 0.3f..1.5f, "${(s.bgBrightness * 100).toInt()}%") { v -> u { it.copy(bgBrightness = v) } }
                SliderRow("Dimming", s.bgDim, 0f..0.85f, "${(s.bgDim * 100).toInt()}%") { v -> u { it.copy(bgDim = v) } }
                SliderRow("Blur", s.bgBlur, 0f..25f, "${s.bgBlur.toInt()} dp") { v -> u { it.copy(bgBlur = v) } }
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                    Text("Blur needs Android 12 or newer; on this phone use Dimming instead.", color = c.textDim, fontSize = 12.sp)
                }
                Text(
                    "A minimum dim is always applied so text stays readable over bright images.",
                    color = c.textDim,
                    fontSize = 12.sp
                )
            }
            else -> Unit
        }

        SubTitle("Texture / pattern")
        ChoiceChips(
            listOf(
                BgTexture.NONE to "None",
                BgTexture.GRID to "Grid",
                BgTexture.DOTS to "Dots",
                BgTexture.DIAGONAL to "Diagonal lines"
            ),
            s.bgTexture
        ) { t -> u { it.copy(bgTexture = t) } }
    }
}
