package com.reo.games.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.data.db.GameCategory
import com.reo.games.ui.theme.LocalReoColors

/** اختيار إحدى الفئات الخمس (يلتف على أكثر من سطر في الشاشات الضيقة). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CategoryPicker(
    selected: GameCategory,
    onSelect: (GameCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = LocalReoColors.current
    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        GameCategory.entries.forEach { cat ->
            val on = cat == selected
            val shape = RoundedCornerShape(50)
            Text(
                cat.label,
                color = if (on) c.onAccent else c.textPrimary,
                fontSize = 14.sp,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier
                    .clip(shape)
                    .background(if (on) c.accent else c.surface)
                    .border(1.dp, if (on) c.accent else c.outline, shape)
                    .clickable { onSelect(cat) }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            )
        }
    }
}
