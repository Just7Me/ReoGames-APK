package com.reo.games.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.net.Uri
import com.reo.games.data.ImportMode
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.CategoryStyle
import com.reo.games.data.settings.SortOrder
import com.reo.games.data.settings.ThemeMode
import com.reo.games.data.settings.ThemePreset
import com.reo.games.ui.MainViewModel
import com.reo.games.ui.theme.LocalReoColors
import com.reo.games.ui.theme.accentOf

// ------------------------------------------------------------------ الثيم

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ThemeSection(vm: MainViewModel, s: AppSettings) {
    val c = LocalReoColors.current
    val u = vm::updateSettings
    SettingsSection("Theme & colors") {
        SubTitle("Presets")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemePreset.entries.filter { it != ThemePreset.CUSTOM }.forEach { p ->
                val on = s.themePreset == p
                val accent = accentOf(AppSettings(themePreset = p))
                val shape = RoundedCornerShape(12.dp)
                Row(
                    Modifier
                        .clip(shape)
                        .background(if (on) c.surfaceHigh else c.surface)
                        .border(if (on) 2.dp else 1.dp, if (on) accent else c.outline, shape)
                        .clickable { u { it.copy(themePreset = p) } }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(accent))
                    Spacer(Modifier.width(8.dp))
                    Text(p.label, color = c.textPrimary, fontSize = 13.5.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
        SubTitle("Custom accent color")
        ColorRow(
            label = if (s.themePreset == ThemePreset.CUSTOM) "Accent (active)" else "Accent (tap to use custom)",
            color = s.customAccent
        ) { col -> u { it.copy(customAccent = col, themePreset = ThemePreset.CUSTOM) } }

        SubTitle("Mode")
        ChoiceChips(
            listOf(ThemeMode.DARK to "Dark", ThemeMode.LIGHT to "Light", ThemeMode.SYSTEM to "Follow system"),
            s.themeMode
        ) { m -> u { it.copy(themeMode = m) } }
        Text(
            "The accent color is used for the selected category, buttons, sliders, progress and highlights.",
            color = c.textDim, fontSize = 12.sp
        )
    }
}

// ------------------------------------------------------------------ الشريط العلوي والفئات

@Composable
fun TopBarSection(vm: MainViewModel, s: AppSettings) {
    val u = vm::updateSettings
    SettingsSection("Top bar & categories") {
        SwitchRow("Show app name", s.showAppName) { v -> u { it.copy(showAppName = v) } }
        SwitchRow("Show category counts", s.showCounts) { v -> u { it.copy(showCounts = v) } }
        SwitchRow(
            "Show search shortcut", s.showSearchShortcut,
            hint = "When hidden, search is still in the sort menu next to the categories"
        ) { v -> u { it.copy(showSearchShortcut = v) } }
        SwitchRow(
            "Add & Settings as icons", s.iconButtons,
            hint = "Off = text buttons"
        ) { v -> u { it.copy(iconButtons = v) } }
        SubTitle("Toolbar size")
        ChoiceChips(listOf(true to "Compact", false to "Comfortable"), s.toolbarCompact) { b -> u { it.copy(toolbarCompact = b) } }
        SubTitle("Category style")
        ChoiceChips(
            listOf(CategoryStyle.TEXT to "Text tabs", CategoryStyle.PILL to "Pills", CategoryStyle.UNDERLINE to "Underlined"),
            s.categoryStyle
        ) { st -> u { it.copy(categoryStyle = st) } }
        SliderRow("Category spacing", s.categorySpacing, 0f..24f, "${s.categorySpacing.toInt()} dp") { v -> u { it.copy(categorySpacing = v) } }
    }
}

// ------------------------------------------------------------------ التفاعل

@Composable
fun InteractionSection(vm: MainViewModel, s: AppSettings) {
    val u = vm::updateSettings
    SettingsSection("Cards & interaction") {
        SwitchRow("Animations", s.animations, hint = "Turn off to save battery") { v -> u { it.copy(animations = v) } }
        SwitchRow("Card press animation", s.pressAnimation, enabled = s.animations) { v -> u { it.copy(pressAnimation = v) } }
        SwitchRow("Haptic feedback", s.haptics) { v -> u { it.copy(haptics = v) } }
        SwitchRow("Remember last category", s.rememberCategory) { v -> u { it.copy(rememberCategory = v) } }
        SwitchRow("Confirm before removing games", s.confirmRemove) { v -> u { it.copy(confirmRemove = v) } }
        SwitchRow("Progress bar on Playing games", s.showProgressPlaying) { v -> u { it.copy(showProgressPlaying = v) } }
        SwitchRow("Category badge on cards", s.showCategoryBadge) { v -> u { it.copy(showCategoryBadge = v) } }
        SubTitle("Default sorting")
        ChoiceChips(SortOrder.entries.map { it to it.label }, s.defaultSort) { o -> u { it.copy(defaultSort = o) } }
    }
}

// ------------------------------------------------------------------ بيانات: النسخ الاحتياطي ومفتاح API

@Composable
fun DataSection(vm: MainViewModel) {
    val c = LocalReoColors.current
    var pendingImport by remember { mutableStateOf<Uri?>(null) }
    var confirmReplace by remember { mutableStateOf(false) }
    var keyDialog by remember { mutableStateOf(false) }
    val hasKey by vm.hasKey.collectAsState()

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportLibrary(uri)
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) pendingImport = uri
    }

    SettingsSection("Library data") {
        Text(
            "Backups are JSON files. They include every game, its category and your tracking info " +
                "(playtime, progress, rating, notes, dates). Online covers are saved as links and " +
                "downloaded again after a restore (needs internet). Covers you added manually are embedded.",
            color = c.textDim, fontSize = 12.5.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { exporter.launch("reo_games_backup.json") }, modifier = Modifier.weight(1f)) { Text("Export") }
            OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }, modifier = Modifier.weight(1f)) { Text("Import") }
        }
        SubTitle("Game database (RAWG)")
        Text(
            if (hasKey) "An API key is set." else "No API key set — online search is disabled until you add one.",
            color = if (hasKey) c.textPrimary else Color(0xFFFFB454), fontSize = 13.5.sp
        )
        OutlinedButton(onClick = { keyDialog = true }, modifier = Modifier.fillMaxWidth()) {
            Text(if (hasKey) "Change API key" else "Enter API key")
        }
    }

    pendingImport?.let { uri ->
        AlertDialog(
            onDismissRequest = { pendingImport = null },
            title = { Text("Import backup") },
            text = {
                Text(
                    "Merge adds games that aren't already in your library (duplicates are skipped). " +
                        "Replace deletes your current library first."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.importLibrary(uri, ImportMode.MERGE); pendingImport = null }) { Text("Merge") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingImport = null }) { Text("Cancel") }
                    TextButton(onClick = { confirmReplace = true }) { Text("Replace…", color = Color(0xFFFF5D6C)) }
                }
            }
        )
    }
    if (confirmReplace && pendingImport != null) {
        AlertDialog(
            onDismissRequest = { confirmReplace = false },
            title = { Text("Replace your library?") },
            text = { Text("All current games and notes will be deleted and replaced by the backup. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingImport?.let { vm.importLibrary(it, ImportMode.REPLACE) }
                    pendingImport = null; confirmReplace = false
                }) { Text("Replace", color = Color(0xFFFF5D6C)) }
            },
            dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text("Cancel") } }
        )
    }
    if (keyDialog) {
        var text by remember { mutableStateOf(vm.userKey()) }
        AlertDialog(
            onDismissRequest = { keyDialog = false },
            title = { Text("RAWG API key") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Get a free key at rawg.io/apidocs. It stays on this phone only.", fontSize = 13.sp)
                    OutlinedTextField(
                        value = text, onValueChange = { text = it }, singleLine = true, label = { Text("API key") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = c.accent, unfocusedBorderColor = c.outline, cursorColor = c.accent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.saveKey(text); keyDialog = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { keyDialog = false }) { Text("Cancel") } }
        )
    }
}

// ------------------------------------------------------------------ إدارة الإعدادات

@Composable
fun ManagementSection(vm: MainViewModel, s: AppSettings) {
    val c = LocalReoColors.current
    var confirmAll by remember { mutableStateOf(false) }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportAppearance(uri)
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importAppearance(uri)
    }

    SettingsSection("Manage settings") {
        Text("Resetting never deletes your game library.", color = c.textDim, fontSize = 12.5.sp)
        OutlinedButton(
            onClick = { vm.updateSettings { it.copy(themePreset = ThemePreset.BLUE_NEON, themeMode = ThemeMode.DARK) } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Restore default theme") }
        OutlinedButton(onClick = vm::resetAppearance, modifier = Modifier.fillMaxWidth()) { Text("Reset appearance to defaults") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { exporter.launch("reo_appearance.json") }, modifier = Modifier.weight(1f)) { Text("Export look") }
            OutlinedButton(onClick = { importer.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }, modifier = Modifier.weight(1f)) { Text("Import look") }
        }
        Button(
            onClick = { confirmAll = true },
            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E), contentColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Reset all settings") }
        Text("Reo Games 1.0 · no account, no ads, all data stays on your phone", color = c.textDim, fontSize = 11.5.sp)
    }

    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            title = { Text("Reset all settings?") },
            text = { Text("Appearance, layout and interaction settings go back to defaults. Your games and notes are not touched. Your saved API key is kept.") },
            confirmButton = { TextButton(onClick = { confirmAll = false; vm.resetAll() }) { Text("Reset", color = Color(0xFFFF5D6C)) } },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel") } }
        )
    }
}
