package com.reo.games.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.AspectMode
import com.reo.games.ui.theme.LocalReoColors

/** ما تحتاجه البطاقة للعرض (منفصل عن كيان قاعدة البيانات ليخدم المعاينة أيضاً). */
data class CardModel(
    val id: Long,
    val title: String,
    val year: Int?,
    val cover: Any?,
    /** null = لا يُعرض شريط التقدم */
    val progress: Int?,
    /** null = لا تُعرض الشارة */
    val badge: String?
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameCard(
    model: CardModel,
    s: AppSettings,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
    onLongClick: (() -> Unit)? = null
) {
    val c = LocalReoColors.current
    val haptic = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && s.pressAnimation && s.animations) 0.95f else 1f,
        label = "cardPress"
    )

    val shape = RoundedCornerShape(s.cornerRadius.dp)
    val panelPad = if (s.compact) 2.dp else 4.dp
    val coverShape = RoundedCornerShape((s.cornerRadius - panelPad.value).coerceAtLeast(0f).dp)

    var autoRatio by remember(model.id) { mutableFloatStateOf(0.75f) }
    val ratio = when (s.aspect) {
        AspectMode.PORTRAIT -> 2f / 3f
        AspectMode.BOX -> 3f / 4f
        AspectMode.SQUARE -> 1f
        AspectMode.AUTO -> autoRatio
    }

    // على 4 و5 أعمدة نصغّر الخط تلقائياً كي تبقى العناوين مقروءة
    val titleSp = s.titleSize * when (s.columns) { 5 -> 0.82f; 4 -> 0.92f; else -> 1f }
    val density = LocalDensity.current
    val titleMinHeight = with(density) { (titleSp.sp * 1.2f * s.titleLines).toDp() }
    val yearHeight = with(density) { ((titleSp * 0.85f).sp * 1.3f).toDp() }

    var cardMod = modifier
        .scale(pressScale)
    if (s.cardShadow) {
        cardMod = cardMod.shadow(6.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
    }
    if (s.cardGlow) {
        cardMod = cardMod.shadow(
            10.dp, shape,
            ambientColor = c.accent.copy(alpha = 0.9f),
            spotColor = c.accent
        )
    }
    cardMod = cardMod
        .clip(shape)
        .background(c.surface.copy(alpha = s.cardOpacity))
        .let { if (s.cardBorder) it.border(1.dp, c.accent.copy(alpha = 0.35f), shape) else it }
        .combinedClickable(
            interactionSource = interaction,
            indication = null,
            onClick = {
                if (s.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            },
            onLongClick = onLongClick?.let { lc ->
                {
                    if (s.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    lc()
                }
            }
        )
        .padding(panelPad)

    Column(cardMod, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .fillMaxWidth(s.coverScale)
                .aspectRatio(ratio)
                .clip(coverShape)
        ) {
            PlaceholderCover(model)
            if (model.cover != null) {
                AsyncImage(
                    model = model.cover,
                    contentDescription = model.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    onSuccess = { st ->
                        val sz = st.painter.intrinsicSize
                        if (s.aspect == AspectMode.AUTO && sz.width > 0f && sz.height > 0f) {
                            autoRatio = (sz.width / sz.height).coerceIn(0.5f, 1.6f)
                        }
                    }
                )
            }

            if (model.badge != null) {
                Text(
                    model.badge,
                    color = c.onAccent,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(c.accent.copy(alpha = 0.92f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            // وضع مضغوط: العنوان فوق الغلاف عبر تدرج داكن
            if (s.compact && s.showTitle) {
                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.82f))))
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    TitleTexts(model, s, titleSp, Color.White, Color(0xFFD0D6E4), overlay = true)
                }
            }

            if (model.progress != null) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(4.dp)
                        .background(Color.Black.copy(alpha = 0.45f))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(model.progress.coerceIn(0, 100) / 100f)
                            .fillMaxSize()
                            .background(c.accent)
                    )
                }
            }
        }

        if (!s.compact && s.showTitle) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 3.dp, end = 3.dp, top = s.titleGap.dp, bottom = 3.dp)
                    .heightIn(min = titleMinHeight + if (s.showYear) yearHeight else 0.dp)
            ) {
                TitleTexts(model, s, titleSp, c.textPrimary, c.textDim, overlay = false)
            }
        }
    }
}

@Composable
private fun TitleTexts(
    model: CardModel,
    s: AppSettings,
    titleSp: Float,
    titleColor: Color,
    yearColor: Color,
    overlay: Boolean
) {
    val c = LocalReoColors.current
    val align = if (s.titleCenter) TextAlign.Center else TextAlign.Start
    val shadow = if (overlay || c.isDark) Shadow(Color.Black.copy(alpha = 0.7f), blurRadius = 4f) else null
    Text(
        text = model.title,
        color = titleColor,
        maxLines = s.titleLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align,
        fontWeight = FontWeight.Medium,
        style = TextStyle(
            fontSize = titleSp.sp,
            lineHeight = (titleSp * 1.2f).sp,
            shadow = shadow
        ),
        modifier = Modifier.fillMaxWidth()
    )
    if (s.showYear && model.year != null) {
        Text(
            text = model.year.toString(),
            color = yearColor,
            maxLines = 1,
            textAlign = align,
            style = TextStyle(fontSize = (titleSp * 0.85f).sp, lineHeight = (titleSp * 1.1f).sp, shadow = shadow),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** خلفية الغلاف عند غيابه أو أثناء التحميل: تدرج لوني ثابت لكل لعبة + أيقونة. */
@Composable
private fun PlaceholderCover(model: CardModel) {
    val c = LocalReoColors.current
    val hue = remember(model.id, model.title) { ((model.title.hashCode() and 0x7fffffff) % 360).toFloat() }
    val top = remember(hue) { Color.hsv(hue, 0.55f, 0.38f) }
    val bottom = remember(hue) { Color.hsv((hue + 30f) % 360f, 0.65f, 0.16f) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, bottom))),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            Icons.Rounded.SportsEsports,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxSize(0.38f).alpha(if (model.cover == null) 1f else 0.6f)
        )
    }
}
