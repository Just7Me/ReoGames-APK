package com.reo.games.data.net

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

/*
 * نماذج واجهة متجر Steam العامة (غير الرسمية، بلا مفتاح). كل الحقول اختيارية عمداً،
 * وبعض الحقول تُقرأ كـ JsonElement لأن Steam قد يُرجع نوعاً مختلفاً (مثلاً data = [] عند الفشل).
 */

@Serializable
data class SteamSearchResponse(
    val total: Int = 0,
    val items: List<SteamSearchItem> = emptyList()
)

@Serializable
data class SteamSearchItem(
    val type: String? = null,
    val name: String? = null,
    val id: Int = 0,
    /** قد يصل كنص ("94") أو رقم؛ نقرؤه مرناً. */
    val metascore: JsonElement? = null,
    val platforms: SteamPlatforms? = null
)

@Serializable
data class SteamPlatforms(
    val windows: Boolean = false,
    val mac: Boolean = false,
    val linux: Boolean = false
)

@Serializable
data class SteamEnvelope(
    val success: Boolean = false,
    /** كائن عند النجاح، وقد يكون مصفوفة فارغة عند الفشل. */
    val data: JsonElement? = null
)

@Serializable
data class SteamAppData(
    val name: String? = null,
    @SerialName("short_description") val shortDescription: String? = null,
    val developers: List<String>? = null,
    val publishers: List<String>? = null,
    val genres: List<SteamGenre>? = null,
    @SerialName("release_date") val releaseDate: SteamRelease? = null,
    @SerialName("header_image") val headerImage: String? = null,
    val website: String? = null,
    val platforms: SteamPlatforms? = null,
    val metacritic: SteamMeta? = null
)

@Serializable
data class SteamGenre(val description: String? = null)

@Serializable
data class SteamRelease(val date: String? = null)

@Serializable
data class SteamMeta(val score: Int? = null)
