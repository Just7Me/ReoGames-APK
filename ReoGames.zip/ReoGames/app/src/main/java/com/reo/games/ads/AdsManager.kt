package com.reo.games.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.reo.games.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

enum class BannerState { IDLE, LOADING, LOADED, FAILED }

/**
 * مسؤول وحيد عن الإعلانات: موافقة المستخدم (UMP) ← تهيئة SDK مرة واحدة ← بانر واحد صغير (320×50).
 *
 * قواعد:
 *  - لا يُطلب أي إعلان قبل `canRequestAds()` (يحترم موافقة الاتحاد الأوروبي/بريطانيا).
 *  - AdView واحد فقط يُعاد استخدامه بين الشاشات، فلا إعادة تحميل عند التنقل.
 *  - لا نستدعي loadAd يدوياً بعد النجاح: التحديث الدوري يديره AdMob نفسه (اضبطه ≥ 60 ثانية في لوحة AdMob).
 *  - عند الفشل (مثلاً «لا إعلان متاح» لوحدة جديدة): إعادة محاولة بفاصل متصاعد 60 ثم 120 ثم 240 ثم 300 ثانية (سقف)،
 *    وفقط والتطبيق في المقدمة؛ وتتوقف عند الخلفية وتُستأنف عند العودة. التطبيق يعمل دائماً بلا إعلان.
 *  - المعرّفات تأتي من BuildConfig (تجريبية في debug دائماً — انظر app/build.gradle.kts).
 */
class AdsManager(private val app: android.app.Application) {

    private val _bannerState = MutableStateFlow(BannerState.IDLE)
    val bannerState: StateFlow<BannerState> = _bannerState.asStateFlow()

    private val _privacyOptionsRequired = MutableStateFlow(false)
    /** true عندما يوجب القانون (EEA/UK…) إتاحة زر «خيارات الخصوصية» للمستخدم. */
    val privacyOptionsRequired: StateFlow<Boolean> = _privacyOptionsRequired.asStateFlow()

    private val _adStatus = MutableStateFlow("Not started")
    /** نص مقروء لحالة الإعلان، يظهر في الإعدادات ▸ Ads & privacy لتشخيص عدم الظهور. */
    val adStatus: StateFlow<String> = _adStatus.asStateFlow()

    private val main = Handler(Looper.getMainLooper())
    private val sdkInitStarted = AtomicBoolean(false)
    private var sdkReady = false
    private var consentInFlight = false
    private var activityRef: WeakReference<Activity>? = null

    private var banner: AdView? = null
    private var everLoaded = false
    private var foreground = false
    private var failures = 0
    private var lastAttemptMs = 0L

    /** يُستدعى من MainActivity.onCreate. آمن لتكراره (مثلاً بعد إعادة إنشاء النشاط). */
    fun start(activity: Activity) {
        activityRef = WeakReference(activity)
        if (sdkReady) {
            loadBannerIfNeeded(activity)
            return
        }
        if (consentInFlight) return

        _adStatus.value = "Waiting for ad consent…"
        val info = UserMessagingPlatform.getConsentInformation(activity)
        consentInFlight = true
        info.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                // نجح تحديث حالة الموافقة: تُعرض النافذة فقط إن كانت مطلوبة قانونياً
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    consentInFlight = false
                    onConsentResolved(info)
                }
            },
            {
                // فشل الاتصال بخدمة الموافقة: نعتمد على آخر حالة محفوظة (canRequestAds)
                consentInFlight = false
                onConsentResolved(info)
            }
        )
        // مستخدم وافق سابقاً: لا داعي لانتظار الشبكة
        if (info.canRequestAds()) initializeSdk()
    }

    private fun onConsentResolved(info: ConsentInformation) {
        _privacyOptionsRequired.value =
            info.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
        if (info.canRequestAds()) initializeSdk()
        else if (!sdkInitStarted.get()) _adStatus.value = "Ads are off: consent not given"
    }

    /** زر «Privacy choices» في الإعدادات (يظهر فقط عند الإلزام). */
    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) {
            val info = UserMessagingPlatform.getConsentInformation(activity)
            onConsentResolved(info)
        }
    }

    private fun initializeSdk() {
        if (!sdkInitStarted.compareAndSet(false, true)) return
        _adStatus.value = "Starting the ads SDK…"
        // التهيئة خارج الخيط الرئيسي كما توصي Google لتفادي تأخير بدء التطبيق
        Thread {
            MobileAds.initialize(app) {
                main.post {
                    sdkReady = true
                    activityRef?.get()?.let { loadBannerIfNeeded(it) }
                }
            }
        }.start()
    }

    private fun loadBannerIfNeeded(activity: Activity) {
        if (banner != null || !sdkReady) return
        val view = AdView(activity).apply {
            setAdSize(AdSize.BANNER) // 320×50: البانر القياسي الصغير
            adUnitId = BuildConfig.ADMOB_BANNER_UNIT_ID
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    everLoaded = true
                    failures = 0
                    main.removeCallbacks(retryTask)
                    _bannerState.value = BannerState.LOADED
                    _adStatus.value = "Ad loaded"
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    // فشل تحديث دوري بينما إعلان سليم معروض: نُبقيه كما هو
                    if (everLoaded) return
                    failures++
                    _bannerState.value = BannerState.FAILED
                    _adStatus.value = describe(error) + " — will retry automatically"
                    scheduleRetry()
                }
            }
        }
        banner = view
        requestAd(view)
    }

    private fun requestAd(view: AdView) {
        lastAttemptMs = SystemClock.elapsedRealtime()
        _bannerState.value = BannerState.LOADING
        _adStatus.value = "Requesting an ad…"
        view.loadAd(AdRequest.Builder().build())
    }

    private val retryTask = Runnable {
        val view = banner ?: return@Runnable
        if (_bannerState.value == BannerState.FAILED) requestAd(view)
    }

    /** إعادة محاولة بفاصل متصاعد (60/120/240 ثم 300 ثانية). لا تُجدول إلا مرة واحدة في كل مرة. */
    private fun scheduleRetry() {
        main.removeCallbacks(retryTask)
        if (!foreground) return // في الخلفية لا نطلب إعلاناً؛ resume() يستأنف
        val step = (failures - 1).coerceIn(0, 3)
        val delay = (BASE_DELAY_MS shl step).coerceAtMost(MAX_DELAY_MS)
        val wait = (delay - (SystemClock.elapsedRealtime() - lastAttemptMs)).coerceAtLeast(5_000L)
        main.postDelayed(retryTask, wait)
    }

    private fun describe(error: LoadAdError): String {
        val what = when (error.code) {
            0 -> "Internal error"
            1 -> "Invalid request (check that the app ID and banner unit ID belong to the same AdMob app)"
            2 -> "Network error"
            3 -> "No ad available right now (common for new ad units)"
            else -> "Ad failed to load"
        }
        return "$what [code ${error.code}: ${error.message}]"
    }

    /** يضع AdView داخل الحاوية (ينتزعه من حاويته السابقة أولاً). */
    fun attachTo(frame: FrameLayout) {
        val view = banner ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        frame.addView(
            view,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
    }

    fun detachFrom(frame: FrameLayout) = frame.removeAllViews()

    /** في الخلفية: نوقف الإعلان وإعادة المحاولة (لا طلبات والتطبيق غير ظاهر). */
    fun pause() {
        foreground = false
        main.removeCallbacks(retryTask)
        banner?.pause()
    }

    /** عند العودة: نستأنف الإعلان، ونُجدول إعادة المحاولة إن كان آخر طلب فاشلاً. */
    fun resume() {
        foreground = true
        banner?.resume()
        if (_bannerState.value == BannerState.FAILED) scheduleRetry()
    }

    /**
     * عند تدمير النشاط: AdView مرتبط بسياقه فيُحرَّر، ويُعاد إنشاؤه من النشاط الجديد إن وُجد.
     * نتحقق من النشاط حتى لا يلغي onDestroy قديم متأخر عمل نشاط جديد بدأ للتو.
     */
    fun release(activity: Activity) {
        if (banner?.context === activity) {
            main.removeCallbacks(retryTask)
            banner?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
            banner = null
            everLoaded = false
            failures = 0
            _bannerState.value = BannerState.IDLE
            _adStatus.value = "Not started"
        }
        val current = activityRef?.get()
        if (current === activity) {
            activityRef = null
            // إن دُمّر النشاط أثناء نافذة الموافقة قد لا تصل الـ callbacks: نُصفّر العلم ليبدأ النشاط التالي من جديد
            consentInFlight = false
        } else current?.let { loadBannerIfNeeded(it) }
    }

    private companion object {
        const val BASE_DELAY_MS = 60_000L
        const val MAX_DELAY_MS = 300_000L
    }
}

/** يجد النشاط خلف ContextWrapper (لازم لنوافذ الموافقة). */
fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
