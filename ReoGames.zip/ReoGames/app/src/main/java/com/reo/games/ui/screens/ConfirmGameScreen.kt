package com.reo.games.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.composed
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.reo.games.ui.AddGameViewModel
import com.reo.games.ui.components.CategoryPicker
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConfirmGameScreen(
    vm: AddGameViewModel,
    onBack: () -> Unit
) {
    val c = LocalReoColors.current
    val st by vm.confirm.collectAsState()
    val summary = st.summary
    val ctx = LocalContext.current

    ReoScreen(title = "Add to library", onBack = onBack) {
        if (summary == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No game selected", color = c.textDim)
            }
            return@ReoScreen
        }
        val d = st.detail
        val title = d?.name ?: summary.name.orEmpty()
        val cover = d?.backgroundImage ?: summary.backgroundImage
        val year = (d?.released ?: summary.released)?.take(4)
        val developers = d?.developers?.mapNotNull { it.name }?.joinToString(", ")
        val publishers = d?.publishers?.mapNotNull { it.name }?.joinToString(", ")
        val platforms = (d?.platforms ?: summary.platforms)?.mapNotNull { it.platform?.name }.orEmpty()
        val genres = (d?.genres ?: summary.genres)?.mapNotNull { it.name }.orEmpty()
        val rating = (d?.rating ?: summary.rating)?.takeIf { it > 0.0 }
        val website = d?.website?.takeIf { it.startsWith("http") }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // الغلاف + العنوان
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.width(120.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(14.dp)).background(c.surfaceHigh),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.SportsEsports, null, tint = c.textDim.copy(alpha = 0.5f), modifier = Modifier.size(34.dp))
                    if (cover != null) AsyncImage(
                        model = cover, contentDescription = title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(title, color = c.textPrimary, fontSize = 21.sp, fontWeight = FontWeight.Bold, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    if (year != null) Text(year, color = c.textDim, fontSize = 14.sp)
                    if (rating != null) Text("★ %.1f / 5".format(rating), color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    if (!developers.isNullOrBlank()) InfoLine("Developer", developers)
                    if (!publishers.isNullOrBlank()) InfoLine("Publisher", publishers)
                }
            }

            when {
                st.detailLoading -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = c.accent)
                    Spacer(Modifier.width(10.dp))
                    Text("Loading details…", color = c.textDim, fontSize = 13.sp)
                }
                st.detailError != null -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Full details unavailable right now. You can still add the game.",
                        color = c.textDim, fontSize = 13.sp, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = vm::reloadDetail) { Text("Retry") }
                }
            }

            if (genres.isNotEmpty()) TagRow("Genres", genres)
            if (platforms.isNotEmpty()) TagRow("Platforms", platforms)

            val desc = d?.descriptionRaw?.trim().orEmpty()
            if (desc.isNotEmpty()) {
                var expanded by remember { mutableStateOf(false) }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("About", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        desc, color = c.textPrimary, fontSize = 14.sp, lineHeight = 20.sp,
                        maxLines = if (expanded) Int.MAX_VALUE else 5,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (desc.length > 220) {
                        Text(
                            if (expanded) "Show less" else "Read more",
                            color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickableNoRipple { expanded = !expanded }.padding(vertical = 4.dp)
                        )
                    }
                }
            }

            if (website != null) {
                OutlinedButton(onClick = {
                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(website))) }
                }) {
                    Icon(Icons.Rounded.OpenInNew, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Official website")
                }
            }

            Text("Add to category", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            CategoryPicker(selected = st.category, onSelect = vm::setCategory)
            Spacer(Modifier.height(8.dp))
        }

        // شريط الإجراء السفلي
        val existing = st.existing
        Column(
            Modifier.fillMaxWidth().background(c.surface.copy(alpha = 0.96f)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (existing != null) {
                Text(
                    "Already in your library under ${existing.categoryEnum.label}.",
                    color = c.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Medium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.moveExisting(st.category) },
                        enabled = st.category != existing.categoryEnum,
                        modifier = Modifier.weight(1f)) {
                        Text("Move to ${st.category.label}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Button(onClick = { vm.openExisting(existing.id) }, modifier = Modifier.weight(1f)) { Text("Open it") }
                }
            } else {
                Button(
                    onClick = vm::confirmAdd,
                    enabled = !st.saving,
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    if (st.saving) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = c.onAccent)
                    else Text("Add Game to ${st.category.label}", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    val c = LocalReoColors.current
    Text("$label: $value", color = c.textDim, fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TagRow(label: String, items: List<String>) {
    val c = LocalReoColors.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEach {
                Text(
                    it, color = c.textPrimary, fontSize = 12.5.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(c.surface).padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = composed {
    clickable(
        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
}
