package com.reo.games

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.reo.games.data.BackupManager
import com.reo.games.data.GameRepository
import com.reo.games.data.db.ReoDatabase
import com.reo.games.data.net.ApiKeyStore
import com.reo.games.data.net.RawgApi
import com.reo.games.data.settings.SettingsRepository
import kotlinx.serialization.json.Json
import okhttp3.Cache
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

class AppContainer(val app: Application) {

    fun isOnline(): Boolean {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .cache(Cache(File(app.cacheDir, "http"), 20L * 1024 * 1024))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            // دون اتصال: استخدم الاستجابات المخزنة مؤقتاً (حتى 7 أيام)
            .addInterceptor { chain ->
                var req = chain.request()
                if (!isOnline()) {
                    req = req.newBuilder()
                        .header("Cache-Control", "public, only-if-cached, max-stale=${7 * 24 * 3600}")
                        .build()
                }
                chain.proceed(req)
            }
            // تخزين استجابات RAWG مؤقتاً ليوم كامل لتقليل الطلبات
            .addNetworkInterceptor { chain ->
                val resp = chain.proceed(chain.request())
                if (chain.request().url.host == "api.rawg.io") {
                    resp.newBuilder()
                        .removeHeader("Pragma")
                        .header("Cache-Control", "public, max-age=86400")
                        .build()
                } else resp
            }
            .build()
    }

    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

    private val api: RawgApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.rawg.io/api/")
            .client(httpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(RawgApi::class.java)
    }

    val database by lazy { ReoDatabase.get(app) }
    val settings by lazy { SettingsRepository(app) }
    val apiKeys by lazy { ApiKeyStore(app) }
    val games by lazy {
        GameRepository(app, database.gameDao(), api, apiKeys, httpClient) { isOnline() }
    }
    val backup by lazy { BackupManager(app, games, database.gameDao()) }
}

class ReoApp : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .crossfade(true)
            .respectCacheHeaders(false)
            .memoryCache { MemoryCache.Builder(this).maxSizePercent(0.25).build() }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "images"))
                    .maxSizeBytes(250L * 1024 * 1024)
                    .build()
            }
            .build()
}
