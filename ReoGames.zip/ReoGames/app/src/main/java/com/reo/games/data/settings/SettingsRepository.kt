package com.reo.games.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "reo_settings")

private inline fun <reified E : Enum<E>> enumOf(name: String?, default: E): E =
    enumValues<E>().firstOrNull { it.name == name } ?: default

class SettingsRepository(private val context: Context) {

    private object K {
        val bgType = stringPreferencesKey("bgType")
        val bgSolid = intPreferencesKey("bgSolid")
        val bgGradStart = intPreferencesKey("bgGradStart")
        val bgGradEnd = intPreferencesKey("bgGradEnd")
        val bgGradDir = stringPreferencesKey("bgGradDir")
        val bgImagePath = stringPreferencesKey("bgImagePath")
        val bgBrightness = floatPreferencesKey("bgBrightness")
        val bgDim = floatPreferencesKey("bgDim")
        val bgBlur = floatPreferencesKey("bgBlur")
        val bgScale = stringPreferencesKey("bgScale")
        val bgTexture = stringPreferencesKey("bgTexture")

        val columns = intPreferencesKey("columns")
        val coverScale = floatPreferencesKey("coverScale")
        val aspect = stringPreferencesKey("aspect")
        val cornerRadius = floatPreferencesKey("cornerRadius")
        val cardBorder = booleanPreferencesKey("cardBorder")
        val cardShadow = booleanPreferencesKey("cardShadow")
        val cardGlow = booleanPreferencesKey("cardGlow")
        val cardOpacity = floatPreferencesKey("cardOpacity")
        val compact = booleanPreferencesKey("compact")
        val showTitle = booleanPreferencesKey("showTitle")
        val showYear = booleanPreferencesKey("showYear")
        val titleLines = intPreferencesKey("titleLines")
        val titleSize = floatPreferencesKey("titleSize")
        val titleCenter = booleanPreferencesKey("titleCenter")
        val hSpacing = floatPreferencesKey("hSpacing")
        val vSpacing = floatPreferencesKey("vSpacing")
        val titleGap = floatPreferencesKey("titleGap")

        val themePreset = stringPreferencesKey("themePreset")
        val customAccent = intPreferencesKey("customAccent")
        val themeMode = stringPreferencesKey("themeMode")

        val showAppName = booleanPreferencesKey("showAppName")
        val showCounts = booleanPreferencesKey("showCounts")
        val toolbarCompact = booleanPreferencesKey("toolbarCompact")
        val categoryStyle = stringPreferencesKey("categoryStyle")
        val categorySpacing = floatPreferencesKey("categorySpacing")
        val showSearchShortcut = booleanPreferencesKey("showSearchShortcut")
        val iconButtons = booleanPreferencesKey("iconButtons")

        val animations = booleanPreferencesKey("animations")
        val pressAnimation = booleanPreferencesKey("pressAnimation")
        val haptics = booleanPreferencesKey("haptics")
        val defaultSort = stringPreferencesKey("defaultSort")
        val rememberCategory = booleanPreferencesKey("rememberCategory")
        val lastCategory = stringPreferencesKey("lastCategory")
        val confirmRemove = booleanPreferencesKey("confirmRemove")
        val showProgressPlaying = booleanPreferencesKey("showProgressPlaying")
        val showCategoryBadge = booleanPreferencesKey("showCategoryBadge")
    }

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            bgType = enumOf(this[K.bgType], d.bgType),
            bgSolid = this[K.bgSolid] ?: d.bgSolid,
            bgGradStart = this[K.bgGradStart] ?: d.bgGradStart,
            bgGradEnd = this[K.bgGradEnd] ?: d.bgGradEnd,
            bgGradDir = enumOf(this[K.bgGradDir], d.bgGradDir),
            bgImagePath = this[K.bgImagePath] ?: d.bgImagePath,
            bgBrightness = this[K.bgBrightness] ?: d.bgBrightness,
            bgDim = this[K.bgDim] ?: d.bgDim,
            bgBlur = this[K.bgBlur] ?: d.bgBlur,
            bgScale = enumOf(this[K.bgScale], d.bgScale),
            bgTexture = enumOf(this[K.bgTexture], d.bgTexture),
            columns = (this[K.columns] ?: d.columns).coerceIn(2, 5),
            coverScale = (this[K.coverScale] ?: d.coverScale).coerceIn(0.6f, 1f),
            aspect = enumOf(this[K.aspect], d.aspect),
            cornerRadius = this[K.cornerRadius] ?: d.cornerRadius,
            cardBorder = this[K.cardBorder] ?: d.cardBorder,
            cardShadow = this[K.cardShadow] ?: d.cardShadow,
            cardGlow = this[K.cardGlow] ?: d.cardGlow,
            cardOpacity = this[K.cardOpacity] ?: d.cardOpacity,
            compact = this[K.compact] ?: d.compact,
            showTitle = this[K.showTitle] ?: d.showTitle,
            showYear = this[K.showYear] ?: d.showYear,
            titleLines = (this[K.titleLines] ?: d.titleLines).coerceIn(1, 2),
            titleSize = this[K.titleSize] ?: d.titleSize,
            titleCenter = this[K.titleCenter] ?: d.titleCenter,
            hSpacing = this[K.hSpacing] ?: d.hSpacing,
            vSpacing = this[K.vSpacing] ?: d.vSpacing,
            titleGap = this[K.titleGap] ?: d.titleGap,
            themePreset = enumOf(this[K.themePreset], d.themePreset),
            customAccent = this[K.customAccent] ?: d.customAccent,
            themeMode = enumOf(this[K.themeMode], d.themeMode),
            showAppName = this[K.showAppName] ?: d.showAppName,
            showCounts = this[K.showCounts] ?: d.showCounts,
            toolbarCompact = this[K.toolbarCompact] ?: d.toolbarCompact,
            categoryStyle = enumOf(this[K.categoryStyle], d.categoryStyle),
            categorySpacing = this[K.categorySpacing] ?: d.categorySpacing,
            showSearchShortcut = this[K.showSearchShortcut] ?: d.showSearchShortcut,
            iconButtons = this[K.iconButtons] ?: d.iconButtons,
            animations = this[K.animations] ?: d.animations,
            pressAnimation = this[K.pressAnimation] ?: d.pressAnimation,
            haptics = this[K.haptics] ?: d.haptics,
            defaultSort = enumOf(this[K.defaultSort], d.defaultSort),
            rememberCategory = this[K.rememberCategory] ?: d.rememberCategory,
            lastCategory = this[K.lastCategory] ?: d.lastCategory,
            confirmRemove = this[K.confirmRemove] ?: d.confirmRemove,
            showProgressPlaying = this[K.showProgressPlaying] ?: d.showProgressPlaying,
            showCategoryBadge = this[K.showCategoryBadge] ?: d.showCategoryBadge
        )
    }

    private fun androidx.datastore.preferences.core.MutablePreferences.write(s: AppSettings) {
        this[K.bgType] = s.bgType.name
        this[K.bgSolid] = s.bgSolid
        this[K.bgGradStart] = s.bgGradStart
        this[K.bgGradEnd] = s.bgGradEnd
        this[K.bgGradDir] = s.bgGradDir.name
        this[K.bgImagePath] = s.bgImagePath
        this[K.bgBrightness] = s.bgBrightness
        this[K.bgDim] = s.bgDim
        this[K.bgBlur] = s.bgBlur
        this[K.bgScale] = s.bgScale.name
        this[K.bgTexture] = s.bgTexture.name
        this[K.columns] = s.columns
        this[K.coverScale] = s.coverScale
        this[K.aspect] = s.aspect.name
        this[K.cornerRadius] = s.cornerRadius
        this[K.cardBorder] = s.cardBorder
        this[K.cardShadow] = s.cardShadow
        this[K.cardGlow] = s.cardGlow
        this[K.cardOpacity] = s.cardOpacity
        this[K.compact] = s.compact
        this[K.showTitle] = s.showTitle
        this[K.showYear] = s.showYear
        this[K.titleLines] = s.titleLines
        this[K.titleSize] = s.titleSize
        this[K.titleCenter] = s.titleCenter
        this[K.hSpacing] = s.hSpacing
        this[K.vSpacing] = s.vSpacing
        this[K.titleGap] = s.titleGap
        this[K.themePreset] = s.themePreset.name
        this[K.customAccent] = s.customAccent
        this[K.themeMode] = s.themeMode.name
        this[K.showAppName] = s.showAppName
        this[K.showCounts] = s.showCounts
        this[K.toolbarCompact] = s.toolbarCompact
        this[K.categoryStyle] = s.categoryStyle.name
        this[K.categorySpacing] = s.categorySpacing
        this[K.showSearchShortcut] = s.showSearchShortcut
        this[K.iconButtons] = s.iconButtons
        this[K.animations] = s.animations
        this[K.pressAnimation] = s.pressAnimation
        this[K.haptics] = s.haptics
        this[K.defaultSort] = s.defaultSort.name
        this[K.rememberCategory] = s.rememberCategory
        this[K.lastCategory] = s.lastCategory
        this[K.confirmRemove] = s.confirmRemove
        this[K.showProgressPlaying] = s.showProgressPlaying
        this[K.showCategoryBadge] = s.showCategoryBadge
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { it.toSettings() }

    /** يحوّل الإعدادات الحالية بالدالة المعطاة ويكتبها بشكل ذري. */
    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { prefs -> prefs.write(transform(prefs.toSettings())) }
    }

    suspend fun resetAppearance() = update { it.withDefaultAppearance() }

    suspend fun resetAll() {
        context.dataStore.edit { it.clear() }
    }

    /** تصدير إعدادات المظهر فقط (بدون lastCategory ومسار الخلفية الداخلي) إلى JSON. */
    suspend fun exportAppearanceJson(current: AppSettings): String {
        val o = JSONObject()
        o.put("type", "reo_appearance")
        o.put("version", 1)
        val s = JSONObject()
        val d = current
        s.put("bgType", d.bgType.name); s.put("bgSolid", d.bgSolid)
        s.put("bgGradStart", d.bgGradStart); s.put("bgGradEnd", d.bgGradEnd)
        s.put("bgGradDir", d.bgGradDir.name); s.put("bgBrightness", d.bgBrightness.toDouble())
        s.put("bgDim", d.bgDim.toDouble()); s.put("bgBlur", d.bgBlur.toDouble())
        s.put("bgScale", d.bgScale.name); s.put("bgTexture", d.bgTexture.name)
        s.put("columns", d.columns); s.put("coverScale", d.coverScale.toDouble())
        s.put("aspect", d.aspect.name); s.put("cornerRadius", d.cornerRadius.toDouble())
        s.put("cardBorder", d.cardBorder); s.put("cardShadow", d.cardShadow)
        s.put("cardGlow", d.cardGlow); s.put("cardOpacity", d.cardOpacity.toDouble())
        s.put("compact", d.compact); s.put("showTitle", d.showTitle)
        s.put("showYear", d.showYear); s.put("titleLines", d.titleLines)
        s.put("titleSize", d.titleSize.toDouble()); s.put("titleCenter", d.titleCenter)
        s.put("hSpacing", d.hSpacing.toDouble()); s.put("vSpacing", d.vSpacing.toDouble())
        s.put("titleGap", d.titleGap.toDouble())
        s.put("themePreset", d.themePreset.name); s.put("customAccent", d.customAccent)
        s.put("themeMode", d.themeMode.name)
        s.put("showAppName", d.showAppName); s.put("showCounts", d.showCounts)
        s.put("toolbarCompact", d.toolbarCompact); s.put("categoryStyle", d.categoryStyle.name)
        s.put("categorySpacing", d.categorySpacing.toDouble())
        s.put("showSearchShortcut", d.showSearchShortcut); s.put("iconButtons", d.iconButtons)
        o.put("settings", s)
        return o.toString(2)
    }

    /** يستورد ملف مظهر؛ يعيد true عند النجاح. صورة الخلفية المخصصة لا تُستورد (مسار محلي). */
    suspend fun importAppearanceJson(text: String): Boolean {
        return try {
            val root = JSONObject(text)
            if (root.optString("type") != "reo_appearance") return false
            val s = root.getJSONObject("settings")
            update { c ->
                val importedType = enumOf(s.optString("bgType"), c.bgType)
                c.copy(
                    // الصورة غير متضمنة: إن كان النوع IMAGE نعود للخلفية الافتراضية
                    bgType = if (importedType == BgType.IMAGE) BgType.DEFAULT else importedType,
                    bgSolid = s.optInt("bgSolid", c.bgSolid),
                    bgGradStart = s.optInt("bgGradStart", c.bgGradStart),
                    bgGradEnd = s.optInt("bgGradEnd", c.bgGradEnd),
                    bgGradDir = enumOf(s.optString("bgGradDir"), c.bgGradDir),
                    bgBrightness = s.optDouble("bgBrightness", c.bgBrightness.toDouble()).toFloat(),
                    bgDim = s.optDouble("bgDim", c.bgDim.toDouble()).toFloat(),
                    bgBlur = s.optDouble("bgBlur", c.bgBlur.toDouble()).toFloat(),
                    bgScale = enumOf(s.optString("bgScale"), c.bgScale),
                    bgTexture = enumOf(s.optString("bgTexture"), c.bgTexture),
                    columns = s.optInt("columns", c.columns).coerceIn(2, 5),
                    coverScale = s.optDouble("coverScale", c.coverScale.toDouble()).toFloat().coerceIn(0.6f, 1f),
                    aspect = enumOf(s.optString("aspect"), c.aspect),
                    cornerRadius = s.optDouble("cornerRadius", c.cornerRadius.toDouble()).toFloat(),
                    cardBorder = s.optBoolean("cardBorder", c.cardBorder),
                    cardShadow = s.optBoolean("cardShadow", c.cardShadow),
                    cardGlow = s.optBoolean("cardGlow", c.cardGlow),
                    cardOpacity = s.optDouble("cardOpacity", c.cardOpacity.toDouble()).toFloat(),
                    compact = s.optBoolean("compact", c.compact),
                    showTitle = s.optBoolean("showTitle", c.showTitle),
                    showYear = s.optBoolean("showYear", c.showYear),
                    titleLines = s.optInt("titleLines", c.titleLines).coerceIn(1, 2),
                    titleSize = s.optDouble("titleSize", c.titleSize.toDouble()).toFloat(),
                    titleCenter = s.optBoolean("titleCenter", c.titleCenter),
                    hSpacing = s.optDouble("hSpacing", c.hSpacing.toDouble()).toFloat(),
                    vSpacing = s.optDouble("vSpacing", c.vSpacing.toDouble()).toFloat(),
                    titleGap = s.optDouble("titleGap", c.titleGap.toDouble()).toFloat(),
                    themePreset = enumOf(s.optString("themePreset"), c.themePreset),
                    customAccent = s.optInt("customAccent", c.customAccent),
                    themeMode = enumOf(s.optString("themeMode"), c.themeMode),
                    showAppName = s.optBoolean("showAppName", c.showAppName),
                    showCounts = s.optBoolean("showCounts", c.showCounts),
                    toolbarCompact = s.optBoolean("toolbarCompact", c.toolbarCompact),
                    categoryStyle = enumOf(s.optString("categoryStyle"), c.categoryStyle),
                    categorySpacing = s.optDouble("categorySpacing", c.categorySpacing.toDouble()).toFloat(),
                    showSearchShortcut = s.optBoolean("showSearchShortcut", c.showSearchShortcut),
                    iconButtons = s.optBoolean("iconButtons", c.iconButtons)
                )
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
