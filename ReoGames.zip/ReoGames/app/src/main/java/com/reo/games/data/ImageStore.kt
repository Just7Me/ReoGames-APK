package com.reo.games.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import kotlin.math.max

/** نسخ الصور داخل مساحة التطبيق (لا حاجة لأذونات URI دائمة) مع تصغيرها. */
object ImageStore {

    fun coversDir(context: Context) = File(context.filesDir, "covers").apply { mkdirs() }
    fun wallpaperFile(context: Context) = File(context.filesDir, "wallpaper.jpg")

    /** ينسخ صورة من Uri إلى [dest] بعد تصغيرها وتصحيح اتجاهها. */
    fun importUri(context: Context, uri: Uri, dest: File, maxDim: Int): Boolean {
        return try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false

            var sample = 1
            while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false

            val rotation = try {
                resolver.openInputStream(uri)?.use { s ->
                    when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
            } catch (e: Exception) { 0f }

            val scale = maxDim.toFloat() / max(bmp.width, bmp.height)
            if (scale < 1f || rotation != 0f) {
                val m = Matrix().apply {
                    if (scale < 1f) postScale(scale, scale)
                    if (rotation != 0f) postRotate(rotation)
                }
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            dest.parentFile?.mkdirs()
            dest.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** تنزيل غلاف من رابط إلى ملف محلي (أفضل جهد؛ يعيد false عند الفشل). */
    fun downloadTo(client: OkHttpClient, url: String, dest: File): Boolean {
        return try {
            client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
                if (!resp.isSuccessful) return false
                val body = resp.body ?: return false
                dest.parentFile?.mkdirs()
                val tmp = File(dest.parentFile, dest.name + ".tmp")
                tmp.outputStream().use { out -> body.byteStream().copyTo(out) }
                tmp.renameTo(dest)
            }
        } catch (e: Exception) {
            false
        }
    }
}
