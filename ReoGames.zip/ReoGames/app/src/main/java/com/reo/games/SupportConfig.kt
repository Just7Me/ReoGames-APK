package com.reo.games

import android.net.Uri

/**
 * ✦ المكان الوحيد لإعدادات صفحة «Support the Developer» ✦
 *
 * لا تعدّل هذا الملف. الروابط تُضبط وقت البناء من خارج الشيفرة (انظر README ▸ «الإعلانات والدعم»):
 *   DONATION_URL        رابط صفحة التبرع الخارجية التي تستضيفها أنت (https فقط)
 *   PROJECT_GITHUB_URL  رابط مشروع GitHub (اختياري)
 *   PRIVACY_POLICY_URL  رابط سياسة الخصوصية (اختياري؛ مطلوب من Google Play عند استخدام الإعلانات)
 * من الهاتف: GitHub ▸ المستودع ▸ Settings ▸ Secrets and variables ▸ Actions ▸ Variables.
 * من Android Studio: ضعها في ملف local.properties بنفس الأسماء.
 *
 * إن تُركت فارغة أو كانت غير صالحة: لا يُفتح أي رابط، وتعرض الصفحة رسالة «غير متاحة بعد».
 * التطبيق لا ينشئ حساب تبرع ولا يدمج أي نظام دفع؛ يفتح فقط الرابط الذي تضعه أنت في المتصفح.
 */
object SupportConfig {
    val donationUrl: String? = valid(BuildConfig.DONATION_URL)
    val githubUrl: String? = valid(BuildConfig.GITHUB_URL)
    val privacyPolicyUrl: String? = valid(BuildConfig.PRIVACY_POLICY_URL)

    private fun valid(raw: String): String? {
        val v = raw.trim()
        if (!v.startsWith("https://")) return null
        return if (!Uri.parse(v).host.isNullOrBlank()) v else null
    }
}
