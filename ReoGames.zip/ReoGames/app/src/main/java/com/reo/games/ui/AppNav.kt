package com.reo.games.ui

import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.ui.components.ReoBackground
import com.reo.games.ui.screens.AddGameScreen
import com.reo.games.ui.screens.ConfirmGameScreen
import com.reo.games.ui.screens.DetailsScreen
import com.reo.games.ui.screens.LibraryScreen
import com.reo.games.ui.screens.LibrarySearchScreen
import com.reo.games.ui.screens.ManualAddScreen
import com.reo.games.ui.screens.SettingsScreen
import com.reo.games.ui.screens.SupportScreen
import com.reo.games.ads.AdsManager
import com.reo.games.ads.BannerSlot
import com.reo.games.ads.LocalBannerShown
import com.reo.games.ads.shouldShowBanner
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import com.reo.games.data.settings.AppSettings

private object Route {
    const val LIBRARY = "library"
    const val SEARCH = "search"
    const val ADD = "add"
    const val CONFIRM = "confirm"
    const val MANUAL = "manual?title={title}"
    const val DETAILS = "details/{id}"
    const val SETTINGS = "settings"
    const val SUPPORT = "support"
    fun details(id: Long) = "details/$id"
    fun manual(title: String) = "manual?title=${Uri.encode(title)}"
}

@Composable
fun AppNav(vm: MainViewModel, addVm: AddGameViewModel, s: AppSettings, ads: AdsManager) {
    val nav = rememberNavController()
    val snackbar = remember { SnackbarHostState() }
    val games by vm.games.collectAsState()
    val selected by vm.selected.collectAsState()
    var duplicate by remember { mutableStateOf<GameEntity?>(null) }

    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    LaunchedEffect(Unit) {
        addVm.events.collect { ev ->
            when (ev) {
                is AddEvent.Added -> {
                    vm.selectCategory(ev.category)
                    nav.popBackStack(Route.LIBRARY, inclusive = false)
                    vm.toast("Added \"${ev.title}\" to ${ev.category.label}")
                    addVm.resetSearch()
                }
                is AddEvent.Duplicate -> duplicate = ev.existing
                is AddEvent.OpenExisting -> {
                    nav.popBackStack(Route.LIBRARY, inclusive = false)
                    nav.navigate(Route.details(ev.id))
                }
            }
        }
    }

    // البانر فقط في الشاشات الرئيسية (المكتبة، البحث داخل المكتبة، التفاصيل)
    // لا يظهر أثناء الإضافة/الإعدادات/صفحة الدعم ولا مع لوحة المفاتيح
    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route
    val bannerShown = shouldShowBanner(ads, route == Route.LIBRARY || route == Route.SEARCH || route == Route.DETAILS)

    val dur = if (s.animations) 260 else 0
    CompositionLocalProvider(LocalBannerShown provides bannerShown) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                NavHost(
                    navController = nav,
                    startDestination = Route.LIBRARY,
                    enterTransition = { if (s.animations) slideInHorizontally(tween(dur)) { it / 6 } + fadeIn(tween(dur)) else EnterTransition.None },
                    exitTransition = { if (s.animations) fadeOut(tween(dur)) else ExitTransition.None },
                    popEnterTransition = { if (s.animations) fadeIn(tween(dur)) else EnterTransition.None },
                    popExitTransition = { if (s.animations) slideOutHorizontally(tween(dur)) { it / 6 } + fadeOut(tween(dur)) else ExitTransition.None }
                ) {
                    composable(Route.LIBRARY) {
                        // الخلفية المخصصة تخص الشاشة الرئيسية فقط
                        ReoBackground(s) {
                            LibraryScreen(
                                vm = vm, s = s,
                                onOpenGame = { nav.navigate(Route.details(it)) },
                                onAdd = { cat ->
                                    addVm.startNewSession(cat)
                                    nav.navigate(Route.ADD)
                                },
                                onSearch = { nav.navigate(Route.SEARCH) },
                                onSettings = { nav.navigate(Route.SETTINGS) }
                            )
                        }
                    }
                    composable(Route.SEARCH) {
                        LibrarySearchScreen(vm, s, onBack = { nav.popBackStack() }, onOpenGame = { nav.navigate(Route.details(it)) })
                    }
                    composable(Route.ADD) {
                        val key by vm.hasKey.collectAsState()
                        AddGameScreen(
                            vm = addVm,
                            libraryRawgIds = games.orEmpty().mapNotNull { it.rawgId }.toSet(),
                            savedKey = if (key) vm.userKey() else "",
                            onSaveKey = vm::saveKey,
                            onBack = { nav.popBackStack() },
                            onPick = { addVm.select(it); nav.navigate(Route.CONFIRM) },
                            onManual = { nav.navigate(Route.manual(it)) }
                        )
                    }
                    composable(Route.CONFIRM) {
                        ConfirmGameScreen(vm = addVm, onBack = { nav.popBackStack() })
                    }
                    composable(
                        Route.MANUAL,
                        arguments = listOf(navArgument("title") { type = NavType.StringType; defaultValue = "" })
                    ) { entry ->
                        ManualAddScreen(
                            vm = addVm,
                            initialTitle = entry.arguments?.getString("title").orEmpty(),
                            initialCategory = addVm.defaultCategory,
                            onBack = { nav.popBackStack() }
                        )
                    }
                    composable(
                        Route.DETAILS,
                        arguments = listOf(navArgument("id") { type = NavType.LongType })
                    ) { entry ->
                        DetailsScreen(
                            vm = vm,
                            gameId = entry.arguments?.getLong("id") ?: -1L,
                            confirmRemove = s.confirmRemove,
                            onBack = { nav.popBackStack() }
                        )
                    }
                    composable(Route.SETTINGS) {
                        SettingsScreen(vm, s, ads, onBack = { nav.popBackStack() }, onSupport = { nav.navigate(Route.SUPPORT) })
                    }
                    composable(Route.SUPPORT) {
                        SupportScreen(onBack = { nav.popBackStack() })
                    }
                }

                SnackbarHost(
                    hostState = snackbar,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .then(if (bannerShown) Modifier else Modifier.navigationBarsPadding())
                )
            }
            if (bannerShown) BannerSlot(ads)
        }
    }

    duplicate?.let { ex ->
        AlertDialog(
            onDismissRequest = { duplicate = null },
            title = { Text("Already in your library") },
            text = { Text("\"${ex.title}\" is already in ${ex.categoryEnum.label}. You can open it to change its category instead of adding a duplicate.") },
            confirmButton = {
                TextButton(onClick = { duplicate = null; addVm.openExisting(ex.id) }) { Text("Open it") }
            },
            dismissButton = { TextButton(onClick = { duplicate = null }) { Text("OK") } }
        )
    }
}
