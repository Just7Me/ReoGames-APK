package com.reo.games.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.reo.games.data.db.GameEntity
import com.reo.games.ui.theme.LocalReoColors
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset

private fun parseHours(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it >= 0 }

/** يحوّل لحظة محلية إلى منتصف الليل UTC (ما يتوقعه DatePicker). */
private fun toPickerMillis(localMillis: Long): Long =
    Instant.ofEpochMilli(localMillis).atZone(ZoneId.systemDefault()).toLocalDate()
        .atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()

/** يحوّل اختيار DatePicker (UTC) إلى منتصف الليل المحلي لنفس التاريخ. */
private fun fromPickerMillis(utcMillis: Long): Long =
    Instant.ofEpochMilli(utcMillis).atZone(ZoneOffset.UTC).toLocalDate()
        .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EditTrackingDialog(
    game: GameEntity,
    onDismiss: () -> Unit,
    onSave: (GameEntity) -> Unit
) {
    val c = LocalReoColors.current

    // rememberSaveable: لا تضيع التعديلات عند تدوير الشاشة
    var hours by rememberSaveable { mutableStateOf(game.playtimeHours?.let { if (it % 1.0 == 0.0) it.toInt().toString() else it.toString() } ?: "") }
    var progress by rememberSaveable { mutableStateOf(game.progress) }
    var rating by rememberSaveable { mutableStateOf(game.personalRating) }
    var notes by rememberSaveable { mutableStateOf(game.notes.orEmpty()) }
    var completed by rememberSaveable { mutableStateOf(game.dateCompleted) }
    var showDate by rememberSaveable { mutableStateOf(false) }
    var showDiscard by rememberSaveable { mutableStateOf(false) }

    val hoursValid = hours.isBlank() || parseHours(hours) != null
    val dirty = parseHours(hours) != game.playtimeHours || progress != game.progress ||
        rating != game.personalRating || notes.trim() != game.notes.orEmpty().trim() ||
        completed != game.dateCompleted

    val requestClose = { if (dirty) showDiscard = true else onDismiss() }

    Dialog(
        onDismissRequest = requestClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = c.surface,
            modifier = Modifier.fillMaxWidth(0.94f).widthIn(max = 560.dp).heightIn(max = 640.dp)
        ) {
            Column {
                Text(
                    "My tracking",
                    color = c.textPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 20.dp, top = 18.dp, end = 20.dp, bottom = 6.dp)
                )
                Column(
                    Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedTextField(
                        value = hours, onValueChange = { hours = it.take(7) },
                        label = { Text("Playtime (hours)") }, singleLine = true,
                        isError = !hoursValid,
                        supportingText = if (!hoursValid) ({ Text("Enter a number, e.g. 12.5") }) else null,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = fieldColors(), shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // التقدم
                    Column {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Progress", color = c.textDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text(progress?.let { "$it%" } ?: "Not set", color = c.textPrimary, fontWeight = FontWeight.SemiBold)
                            if (progress != null) TextButton(onClick = { progress = null }) { Text("Clear") }
                        }
                        Slider(
                            value = (progress ?: 0).toFloat(),
                            onValueChange = { progress = it.toInt() },
                            valueRange = 0f..100f,
                            colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.outline)
                        )
                    }

                    // التقييم 1–10
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("My rating", color = c.textDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            if (rating != null) TextButton(onClick = { rating = null }) { Text("Clear") }
                        }
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            (1..10).forEach { n ->
                                val on = rating == n
                                Box(
                                    Modifier.size(38.dp).clip(CircleShape)
                                        .background(if (on) c.accent else c.surfaceHigh)
                                        .clickable { rating = if (on) null else n },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(n.toString(), color = if (on) c.onAccent else c.textPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                }
                            }
                        }
                    }

                    // تاريخ الإكمال
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Completion date", color = c.textDim, fontSize = 13.sp)
                            Text(completed?.let { fmtDate(it) } ?: "Not set", color = c.textPrimary, fontWeight = FontWeight.Medium)
                        }
                        OutlinedButton(onClick = { showDate = true }) { Text(if (completed == null) "Set" else "Change") }
                        if (completed != null) TextButton(onClick = { completed = null }) { Text("Clear") }
                    }

                    OutlinedTextField(
                        value = notes, onValueChange = { notes = it },
                        label = { Text("Notes") }, minLines = 3, maxLines = 8,
                        colors = fieldColors(), shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = requestClose) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = hoursValid,
                        onClick = {
                            onSave(
                                game.copy(
                                    playtimeHours = parseHours(hours),
                                    progress = progress,
                                    personalRating = rating,
                                    notes = notes.trim().ifEmpty { null },
                                    dateCompleted = completed
                                )
                            )
                        }
                    ) { Text("Save") }
                }
            }
        }
    }

    if (showDate) {
        val state = rememberDatePickerState(initialSelectedDateMillis = completed?.let { toPickerMillis(it) })
        DatePickerDialog(
            onDismissRequest = { showDate = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { completed = fromPickerMillis(it) }
                    showDate = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDate = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }

    if (showDiscard) {
        AlertDialog(
            onDismissRequest = { showDiscard = false },
            title = { Text("Discard changes?") },
            text = { Text("You have unsaved edits to this game's tracking info.") },
            confirmButton = { TextButton(onClick = { showDiscard = false; onDismiss() }) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { showDiscard = false }) { Text("Keep editing") } }
        )
    }
}

@Composable
private fun fieldColors() = LocalReoColors.current.let { c ->
    OutlinedTextFieldDefaults.colors(
        focusedBorderColor = c.accent, unfocusedBorderColor = c.outline,
        cursorColor = c.accent, focusedTextColor = c.textPrimary, unfocusedTextColor = c.textPrimary
    )
}
