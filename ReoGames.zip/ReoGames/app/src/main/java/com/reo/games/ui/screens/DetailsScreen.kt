package com.reo.games.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.ui.MainViewModel
import com.reo.games.ui.components.CategoryPicker
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailsScreen(
    vm: MainViewModel,
    gameId: Long,
    confirmRemove: Boolean,
    onBack: () -> Unit
) {
    val c = LocalReoColors.current
    val ctx = LocalContext.current
    val game by remember(gameId) { vm.observeGame(gameId) }.collectAsState(initial = null)
    var showEdit by remember { mutableStateOf(false) }
    var showRemove by remember { mutableStateOf(false) }

    // اللعبة حُذفت (أو غير موجودة): ارجع تلقائياً
    var seenOnce by remember { mutableStateOf(false) }
    LaunchedEffect(game) {
        if (game != null) seenOnce = true
        else if (seenOnce) onBack()
    }

    val g = game
    ReoScreen(
        title = g?.title ?: "Details",
        onBack = onBack,
        actions = {
            if (g != null) {
                IconButton(onClick = { showEdit = true }) { Icon(Icons.Rounded.Edit, "Edit", tint = c.textPrimary) }
                IconButton(onClick = {
                    if (confirmRemove) showRemove = true else vm.removeGame(g)
                }) { Icon(Icons.Rounded.Delete, "Remove", tint = Color(0xFFFF5D6C)) }
            }
        }
    ) {
        if (g == null) {
            Box(Modifier.fillMaxSize())
            return@ReoScreen
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // الغلاف الكبير
            Box(
                Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(18.dp)).background(c.surfaceHigh)
            ) {
                if (g.coverModel != null) {
                    AsyncImage(
                        model = g.coverModel, contentDescription = g.title,
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(Icons.Rounded.SportsEsports, null, tint = c.textDim.copy(alpha = 0.4f),
                        modifier = Modifier.size(64.dp).align(Alignment.Center))
                }
                Box(
                    Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)), startY = 220f))
                )
                Column(Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                    Text(g.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 3)
                    val sub = listOfNotNull(g.releaseYear?.toString(), g.rating?.let { "★ %.1f".format(it) }).joinToString("  ·  ")
                    if (sub.isNotEmpty()) Text(sub, color = Color(0xFFD0D6E4), fontSize = 13.sp)
                }
            }

            // الفئة الحالية + تغييرها
            Section("Category") {
                CategoryPicker(selected = g.categoryEnum, onSelect = { vm.moveTo(g.id, it) })
            }

            // التتبع الشخصي
            Section("My progress") {
                TrackRow("Playtime", g.playtimeHours?.let { formatHours(it) } ?: "—")
                TrackRow("Progress", g.progress?.let { "$it%" } ?: "—")
                if (g.progress != null) {
                    androidx.compose.material3.LinearProgressIndicator(
                        progress = { (g.progress ?: 0) / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                        color = c.accent, trackColor = c.outline
                    )
                }
                TrackRow("My rating", g.personalRating?.let { "$it / 10" } ?: "—")
                TrackRow("Added", fmtDate(g.dateAdded))
                TrackRow("Completed", g.dateCompleted?.let { fmtDate(it) } ?: "—")
                if (!g.notes.isNullOrBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text("Notes", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(g.notes!!, color = c.textPrimary, fontSize = 14.sp, lineHeight = 20.sp)
                }
                OutlinedButton(onClick = { showEdit = true }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Edit playtime, progress, rating & notes")
                }
            }

            if (!g.description.isNullOrBlank()) {
                Section("About") {
                    Text(g.description!!, color = c.textPrimary, fontSize = 14.sp, lineHeight = 21.sp)
                }
            }

            val hasInfo = listOf(g.developers, g.publishers, g.genres, g.platforms).any { !it.isNullOrBlank() }
            if (hasInfo) {
                Section("Info") {
                    g.developers?.takeIf { it.isNotBlank() }?.let { TrackRow("Developer", it) }
                    g.publishers?.takeIf { it.isNotBlank() }?.let { TrackRow("Publisher", it) }
                    g.releaseDate?.takeIf { it.isNotBlank() }?.let { TrackRow("Released", it) }
                    g.genres?.takeIf { it.isNotBlank() }?.let { Chips("Genres", it) }
                    g.platforms?.takeIf { it.isNotBlank() }?.let { Chips("Platforms", it) }
                }
            }

            val site = g.website?.takeIf { it.startsWith("http") }
            if (site != null) {
                Button(onClick = {
                    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(site))) }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.OpenInNew, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Open official website")
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showEdit && g != null) {
        EditTrackingDialog(
            game = g,
            onDismiss = { showEdit = false },
            onSave = { vm.saveGame(it); showEdit = false }
        )
    }
    if (showRemove && g != null) {
        ConfirmRemoveDialog(g.title, onDismiss = { showRemove = false }) {
            showRemove = false
            vm.removeGame(g)
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    val c = LocalReoColors.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(c.surface.copy(alpha = 0.9f)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp)
        content()
    }
}

@Composable
private fun TrackRow(label: String, value: String) {
    val c = LocalReoColors.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = c.textDim, fontSize = 14.sp)
        Spacer(Modifier.width(12.dp))
        Text(value, color = c.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f, fill = false))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Chips(label: String, csv: String) {
    val c = LocalReoColors.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = c.textDim, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach {
                Text(
                    it, color = c.textPrimary, fontSize = 12.5.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(c.surfaceHigh).padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

internal fun fmtDate(ms: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))

internal fun formatHours(h: Double): String =
    if (h % 1.0 == 0.0) "${h.toInt()} h" else "%.1f h".format(h)
