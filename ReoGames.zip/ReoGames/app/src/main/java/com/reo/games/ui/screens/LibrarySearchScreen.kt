package com.reo.games.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.SortOrder
import com.reo.games.ui.MainViewModel
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors

/** بحث داخل المكتبة: بالعنوان + تصفية حسب النوع والمنصة والسنة والفئة + فرز. */
@Composable
fun LibrarySearchScreen(
    vm: MainViewModel,
    s: AppSettings,
    onBack: () -> Unit,
    onOpenGame: (Long) -> Unit
) {
    val c = LocalReoColors.current
    val filter by vm.filter.collectAsState()
    val results by vm.searchResults.collectAsState()
    val options by vm.filterOptions.collectAsState()
    val requester = remember { FocusRequester() }
    var sheetGame by remember { mutableStateOf<GameEntity?>(null) }
    var removeCandidate by remember { mutableStateOf<GameEntity?>(null) }

    LaunchedEffect(Unit) { runCatching { requester.requestFocus() } }

    ReoScreen(
        title = "Search library",
        onBack = { vm.resetFilter(); onBack() }
    ) {
        OutlinedTextField(
            value = filter.query,
            onValueChange = { q -> vm.setFilter { it.copy(query = q) } },
            singleLine = true,
            placeholder = { Text("Search your games", color = c.textDim) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = c.textDim) },
            trailingIcon = {
                if (filter.query.isNotEmpty()) IconButton(onClick = { vm.setFilter { it.copy(query = "") } }) {
                    Icon(Icons.Rounded.Clear, "Clear", tint = c.textDim)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = c.accent, unfocusedBorderColor = c.outline,
                focusedContainerColor = c.surface, unfocusedContainerColor = c.surface,
                cursorColor = c.accent, focusedTextColor = c.textPrimary, unfocusedTextColor = c.textPrimary
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).focusRequester(requester)
        )

        // شريط الفلاتر
        LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterDropdown(
                    label = "Category",
                    current = filter.category?.label,
                    options = GameCategory.entries.map { it.label },
                    onPick = { i -> vm.setFilter { it.copy(category = i?.let { n -> GameCategory.entries[n] }) } }
                )
            }
            item {
                FilterDropdown("Genre", filter.genre, options.genres) { i ->
                    vm.setFilter { it.copy(genre = i?.let { n -> options.genres[n] }) }
                }
            }
            item {
                FilterDropdown("Platform", filter.platform, options.platforms) { i ->
                    vm.setFilter { it.copy(platform = i?.let { n -> options.platforms[n] }) }
                }
            }
            item {
                FilterDropdown("Year", filter.year?.toString(), options.years.map { it.toString() }) { i ->
                    vm.setFilter { it.copy(year = i?.let { n -> options.years[n] }) }
                }
            }
            item {
                FilterDropdown(
                    label = "Sort",
                    current = (filter.sort ?: s.defaultSort).label,
                    options = SortOrder.entries.map { it.label },
                    allowClear = false,
                    onPick = { i -> if (i != null) vm.setFilter { it.copy(sort = SortOrder.entries[i]) } }
                )
            }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${results.size} game${if (results.size == 1) "" else "s"}", color = c.textDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
            if (filter.isActive) TextButton(onClick = { vm.resetFilter() }) { Text("Clear filters") }
        }

        if (results.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Rounded.SearchOff, null, tint = c.accent, modifier = Modifier.size(42.dp))
                Spacer(Modifier.width(1.dp))
                Text(
                    if (filter.isActive) "No games match these filters" else "Your library is empty",
                    color = c.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
        } else {
            GameGrid(
                list = results,
                s = s,
                onOpen = onOpenGame,
                onLongPress = { sheetGame = it }
            )
        }
    }

    sheetGame?.let { g ->
        QuickActionsSheet(
            game = g,
            onDismiss = { sheetGame = null },
            onOpen = { sheetGame = null; onOpenGame(g.id) },
            onMove = { cat -> sheetGame = null; vm.moveTo(g.id, cat) },
            onRemove = {
                sheetGame = null
                if (s.confirmRemove) removeCandidate = g else vm.removeGame(g)
            }
        )
    }
    removeCandidate?.let { g ->
        ConfirmRemoveDialog(g.title, onDismiss = { removeCandidate = null }) {
            removeCandidate = null
            vm.removeGame(g)
        }
    }
}

/** قائمة منسدلة بشكل "chip". onPick(null) = إزالة الفلتر. */
@Composable
private fun FilterDropdown(
    label: String,
    current: String?,
    options: List<String>,
    allowClear: Boolean = true,
    onPick: (Int?) -> Unit
) {
    val c = LocalReoColors.current
    var open by remember { mutableStateOf(false) }
    val active = current != null && allowClear
    val shape = RoundedCornerShape(50)
    Box {
        Row(
            Modifier
                .clip(shape)
                .background(if (active) c.accent.copy(alpha = 0.18f) else c.surface)
                .border(1.dp, if (active) c.accent else c.outline, shape)
                .clickable { open = true }
                .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (current != null) (if (allowClear) current else "$label: $current") else label,
                color = if (active) c.accent else c.textPrimary,
                fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1
            )
            Icon(Icons.Rounded.ExpandMore, null, tint = c.textDim, modifier = Modifier.size(18.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowClear && current != null) {
                DropdownMenuItem(text = { Text("Any $label") }, onClick = { open = false; onPick(null) })
            }
            if (options.isEmpty()) {
                DropdownMenuItem(text = { Text("Nothing to filter by yet", color = c.textDim) }, enabled = false, onClick = {})
            }
            options.forEachIndexed { i, o ->
                DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onPick(i) })
            }
        }
    }
}
