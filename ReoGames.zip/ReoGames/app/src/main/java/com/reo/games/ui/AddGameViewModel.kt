package com.reo.games.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reo.games.AppContainer
import com.reo.games.data.AddResult
import com.reo.games.data.ApiResult
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameEntity
import com.reo.games.data.net.RawgGameDetail
import com.reo.games.data.net.RawgGameSummary
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface SearchError {
    data object NoKey : SearchError
    data object Offline : SearchError
    data class Message(val text: String) : SearchError
}

data class SearchUiState(
    val query: String = "",
    val results: List<RawgGameSummary> = emptyList(),
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val hasMore: Boolean = false,
    val page: Int = 1,
    /** true بعد إتمام بحث واحد على الأقل لنفس النص (للتمييز بين "لا نتائج" والحالة الأولية) */
    val searched: Boolean = false,
    val error: SearchError? = null
)

data class ConfirmUiState(
    val summary: RawgGameSummary? = null,
    val detail: RawgGameDetail? = null,
    val detailLoading: Boolean = false,
    val detailError: SearchError? = null,
    val category: GameCategory = GameCategory.BACKLOG,
    val existing: GameEntity? = null,
    val saving: Boolean = false
)

sealed interface AddEvent {
    data class Added(val category: GameCategory, val title: String) : AddEvent
    data class Duplicate(val existing: GameEntity) : AddEvent
    data class OpenExisting(val id: Long) : AddEvent
}

@OptIn(FlowPreview::class)
class AddGameViewModel(private val c: AppContainer) : ViewModel() {
    private val repo = c.games

    private val _search = MutableStateFlow(SearchUiState())
    val search: StateFlow<SearchUiState> = _search.asStateFlow()

    private val _confirm = MutableStateFlow(ConfirmUiState())
    val confirm: StateFlow<ConfirmUiState> = _confirm.asStateFlow()

    private val _events = Channel<AddEvent>(Channel.BUFFERED)
    val events = _events.receiveAsFlow()

    private val queryFlow = MutableStateFlow("")

    init {
        viewModelScope.launch {
            queryFlow
                .debounce(450)                 // بحث مؤجل أثناء الكتابة
                .distinctUntilChanged()
                .collectLatest { q -> runSearch(q.trim()) }
        }
    }

    fun onQueryChange(q: String) {
        _search.update { it.copy(query = q) }
        if (q.isBlank()) {
            // امسح النتائج فوراً دون انتظار
            _search.update { it.copy(results = emptyList(), searched = false, error = null, loading = false, hasMore = false, page = 1) }
        } else {
            _search.update { it.copy(loading = true, error = null) }
        }
        queryFlow.value = q
    }

    /** إعادة المحاولة بنفس النص (بعد خطأ مثلاً). */
    fun retry() {
        val q = _search.value.query.trim()
        if (q.isBlank()) return
        viewModelScope.launch {
            _search.update { it.copy(loading = true, error = null) }
            runSearch(q)
        }
    }

    private suspend fun runSearch(q: String) {
        if (q.isBlank()) return
        _search.update { it.copy(loading = true, error = null) }
        when (val r = repo.search(q, 1)) {
            is ApiResult.Success -> _search.update {
                it.copy(
                    results = r.data.results.filter { g -> !g.name.isNullOrBlank() },
                    loading = false, hasMore = r.data.next != null, page = 1,
                    searched = true, error = null
                )
            }
            ApiResult.NoKey -> _search.update { it.copy(loading = false, results = emptyList(), error = SearchError.NoKey, searched = false) }
            ApiResult.Offline -> _search.update { it.copy(loading = false, results = emptyList(), error = SearchError.Offline, searched = false) }
            is ApiResult.Error -> _search.update { it.copy(loading = false, results = emptyList(), error = SearchError.Message(r.message), searched = false) }
        }
    }

    private var moreJob: Job? = null

    fun loadMore() {
        val s = _search.value
        if (s.loading || s.loadingMore || !s.hasMore || moreJob?.isActive == true) return
        val q = s.query.trim()
        moreJob = viewModelScope.launch {
            _search.update { it.copy(loadingMore = true) }
            when (val r = repo.search(q, s.page + 1)) {
                is ApiResult.Success -> _search.update {
                    // نتجاهل النتيجة إن تغيّر النص أثناء التحميل
                    if (it.query.trim() != q) it.copy(loadingMore = false)
                    else it.copy(
                        results = (it.results + r.data.results.filter { g -> !g.name.isNullOrBlank() })
                            .distinctBy { g -> g.id },
                        loadingMore = false, hasMore = r.data.next != null, page = s.page + 1
                    )
                }
                else -> _search.update { it.copy(loadingMore = false, hasMore = false) }
            }
        }
    }

    // ---------------- شاشة التأكيد ----------------

    /** الفئة المحددة وقت الضغط على + (تُستخدم كافتراضي في شاشتي التأكيد والإضافة اليدوية). */
    var defaultCategory: GameCategory = GameCategory.BACKLOG
        private set

    fun startNewSession(category: GameCategory) {
        defaultCategory = category
        resetSearch()
    }

    fun select(summary: RawgGameSummary) {
        _confirm.value = ConfirmUiState(summary = summary, detailLoading = true, category = defaultCategory)
        viewModelScope.launch {
            val existing = repo.findDuplicate(summary.id, summary.name.orEmpty())
            _confirm.update { it.copy(existing = existing) }
        }
        loadDetail(summary.id)
    }

    fun reloadDetail() {
        _confirm.value.summary?.let {
            _confirm.update { s -> s.copy(detailLoading = true, detailError = null) }
            loadDetail(it.id)
        }
    }

    private fun loadDetail(id: Int) {
        viewModelScope.launch {
            when (val r = repo.details(id)) {
                is ApiResult.Success -> _confirm.update { if (it.summary?.id == id) it.copy(detail = r.data, detailLoading = false, detailError = null) else it }
                ApiResult.NoKey -> _confirm.update { it.copy(detailLoading = false, detailError = SearchError.NoKey) }
                ApiResult.Offline -> _confirm.update { it.copy(detailLoading = false, detailError = SearchError.Offline) }
                is ApiResult.Error -> _confirm.update { it.copy(detailLoading = false, detailError = SearchError.Message(r.message)) }
            }
        }
    }

    fun setCategory(cat: GameCategory) = _confirm.update { it.copy(category = cat) }

    fun confirmAdd() {
        val s = _confirm.value
        val summary = s.summary ?: return
        if (s.saving) return
        _confirm.update { it.copy(saving = true) }
        viewModelScope.launch {
            val entity = repo.buildEntity(summary, s.detail, s.category)
            when (val r = repo.add(entity)) {
                is AddResult.Added -> {
                    _confirm.update { it.copy(saving = false) }
                    _events.send(AddEvent.Added(r.category, entity.title))
                }
                is AddResult.Duplicate -> {
                    _confirm.update { it.copy(saving = false, existing = r.existing) }
                    _events.send(AddEvent.Duplicate(r.existing))
                }
            }
        }
    }

    /** نقل لعبة موجودة مسبقاً إلى فئة أخرى من شاشة التأكيد (بدل إنشاء نسخة مكررة). */
    fun moveExisting(cat: GameCategory) {
        val ex = _confirm.value.existing ?: return
        viewModelScope.launch {
            repo.moveTo(ex.id, cat)
            _events.send(AddEvent.Added(cat, ex.title))
        }
    }

    fun openExisting(id: Long) {
        viewModelScope.launch { _events.send(AddEvent.OpenExisting(id)) }
    }

    // ---------------- الإضافة اليدوية ----------------
    fun addManual(title: String, year: Int?, cover: Uri?, cat: GameCategory) {
        viewModelScope.launch {
            when (val r = repo.addManual(title, cover, cat, year)) {
                is AddResult.Added -> _events.send(AddEvent.Added(r.category, title.trim()))
                is AddResult.Duplicate -> _events.send(AddEvent.Duplicate(r.existing))
            }
        }
    }

    fun resetSearch() {
        _search.value = SearchUiState()
        queryFlow.value = ""
        _confirm.value = ConfirmUiState()
    }
}
