package com.reo.games.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** الفئات الخمس للمكتبة. القيمة المخزّنة في قاعدة البيانات هي [key]. */
enum class GameCategory(val key: String, val label: String) {
    PLAYING("playing", "Playing"),
    COMPLETED("completed", "Completed"),
    BACKLOG("backlog", "Backlog"),
    DROPPED("dropped", "Dropped"),
    PLAYED("played", "Played");

    companion object {
        fun fromKey(key: String?): GameCategory =
            entries.firstOrNull { it.key == key } ?: BACKLOG
    }
}

@Entity(
    tableName = "games",
    indices = [Index(value = ["rawgId"], unique = true)]
)
data class GameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** معرّف اللعبة في RAWG. null للألعاب المضافة يدوياً (قيم null المتعددة مسموحة في الفهرس الفريد). */
    val rawgId: Int? = null,
    val title: String,
    /** رابط الغلاف عبر الإنترنت (يُخزَّن مؤقتاً بواسطة Coil). */
    val coverUrl: String? = null,
    /** مسار الغلاف المنسوخ داخل مساحة التطبيق (للألعاب اليدوية). */
    val localCoverPath: String? = null,
    val description: String? = null,
    val releaseDate: String? = null,
    val releaseYear: Int? = null,
    val developers: String? = null,
    val publishers: String? = null,
    val platforms: String? = null,
    val genres: String? = null,
    val rating: Double? = null,
    val website: String? = null,
    val category: String = GameCategory.BACKLOG.key,
    // بيانات التتبع الشخصي (كلها اختيارية)
    val playtimeHours: Double? = null,
    val progress: Int? = null,
    val personalRating: Int? = null,
    val notes: String? = null,
    val dateAdded: Long = System.currentTimeMillis(),
    val dateCompleted: Long? = null,
    /** ترتيب يدوي داخل الفئة (يُستخدم عند السحب والإفلات). */
    val sortIndex: Long = System.currentTimeMillis()
) {
    val categoryEnum: GameCategory get() = GameCategory.fromKey(category)
    /** المصدر المستخدم لعرض الغلاف: الملف المحلي أولاً ثم الرابط. */
    val coverModel: Any?
        get() = localCoverPath
            ?.let { java.io.File(it) }
            ?.takeIf { it.exists() }   // إن حُذف الملف المحلي نعود إلى الرابط الإلكتروني
            ?: coverUrl
}
