package com.reo.games.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.reo.games.data.settings.AppSettings
import com.reo.games.data.settings.BgScale
import com.reo.games.data.settings.BgTexture
import com.reo.games.data.settings.BgType
import com.reo.games.data.settings.GradientDir
import com.reo.games.ui.theme.LocalReoColors
import java.io.File

/**
 * خلفية الشاشة الرئيسية. تدعم: افتراضي / أسود / كحلي / لون / تدرج / صورة من المعرض + نسيج اختياري.
 * ملاحظة: الخلفية لا تمسّ الأغلفة أو بيانات الألعاب.
 */
@Composable
fun ReoBackground(settings: AppSettings, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val c = LocalReoColors.current
    Box(modifier = modifier.fillMaxSize().background(c.bgBase)) {
        when (settings.bgType) {
            BgType.DEFAULT -> Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(c.bgTint, c.bgBase),
                            startY = 0f, endY = size.height
                        )
                    )
                }
            )
            BgType.BLACK -> Box(Modifier.fillMaxSize().background(if (c.isDark) Color.Black else Color.White))
            BgType.NAVY -> Box(
                Modifier.fillMaxSize().drawBehind {
                    drawRect(
                        Brush.verticalGradient(
                            listOf(Color(0xFF0A1A3F), Color(0xFF06112B)),
                            startY = 0f, endY = size.height
                        )
                    )
                }
            )
            BgType.SOLID -> Box(Modifier.fillMaxSize().background(Color(settings.bgSolid)))
            BgType.GRADIENT -> GradientLayer(settings)
            BgType.IMAGE -> ImageLayer(settings)
        }
        if (settings.bgTexture != BgTexture.NONE) TextureLayer(settings.bgTexture, c.isDark)
        content()
    }
}

@Composable
private fun GradientLayer(s: AppSettings) {
    Box(
        Modifier.fillMaxSize().drawBehind {
            val w = size.width
            val h = size.height
            val (start, end) = when (s.bgGradDir) {
                GradientDir.TOP_BOTTOM -> Offset(0f, 0f) to Offset(0f, h)
                GradientDir.BOTTOM_TOP -> Offset(0f, h) to Offset(0f, 0f)
                GradientDir.LEFT_RIGHT -> Offset(0f, 0f) to Offset(w, 0f)
                GradientDir.RIGHT_LEFT -> Offset(w, 0f) to Offset(0f, 0f)
                GradientDir.DIAG_DOWN -> Offset(0f, 0f) to Offset(w, h)
                GradientDir.DIAG_UP -> Offset(0f, h) to Offset(w, 0f)
            }
            drawRect(
                Brush.linearGradient(
                    colors = listOf(Color(s.bgGradStart), Color(s.bgGradEnd)),
                    start = start, end = end
                )
            )
        }
    )
}

@Composable
private fun ImageLayer(s: AppSettings) {
    val file = remember(s.bgImagePath) { if (s.bgImagePath.isNotEmpty()) File(s.bgImagePath) else null }
    if (file == null || !file.exists()) {
        // لا توجد صورة صالحة: ارجع بصرياً للخلفية الافتراضية بدل شاشة فارغة
        Box(Modifier.fillMaxSize().background(Color(0xFF05070D)))
        return
    }
    val b = s.bgBrightness
    val filter = remember(b) {
        ColorFilter.colorMatrix(
            ColorMatrix(
                floatArrayOf(
                    b, 0f, 0f, 0f, 0f,
                    0f, b, 0f, 0f, 0f,
                    0f, 0f, b, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF05070D))) {
        AsyncImage(
            model = file,
            contentDescription = null,
            contentScale = if (s.bgScale == BgScale.COVER) ContentScale.Crop else ContentScale.Fit,
            colorFilter = filter,
            // التمويه يعمل على Android 12 (API 31) وما فوق فقط
            modifier = Modifier.fillMaxSize().blur(s.bgBlur.dp)
        )
        // طبقة تعتيم دائمة بحد أدنى لضمان وضوح النصوص فوق الصور الفاتحة
        val dim = s.bgDim.coerceAtLeast(0.15f)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
        // تدرج علوي إضافي خلف الشريط العلوي
        Box(
            Modifier.fillMaxSize().drawBehind {
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent),
                        startY = 0f, endY = size.height * 0.22f
                    )
                )
            }
        )
    }
}

@Composable
private fun TextureLayer(texture: BgTexture, dark: Boolean) {
    val ink = if (dark) Color.White else Color.Black
    Box(
        Modifier.fillMaxSize().drawWithCache {
            val step = when (texture) {
                BgTexture.GRID -> 30.dp.toPx()
                BgTexture.DOTS -> 22.dp.toPx()
                else -> 22.dp.toPx()
            }
            val w = size.width
            val h = size.height
            val dots = ArrayList<Offset>()
            val path = Path()
            when (texture) {
                BgTexture.GRID -> {
                    var x = 0f
                    while (x <= w) { path.moveTo(x, 0f); path.lineTo(x, h); x += step }
                    var y = 0f
                    while (y <= h) { path.moveTo(0f, y); path.lineTo(w, y); y += step }
                }
                BgTexture.DOTS -> {
                    var y = step / 2
                    while (y <= h) {
                        var x = step / 2
                        while (x <= w) { dots += Offset(x, y); x += step }
                        y += step
                    }
                }
                BgTexture.DIAGONAL -> {
                    var x = -h
                    while (x <= w) { path.moveTo(x, h); path.lineTo(x + h, 0f); x += step }
                }
                BgTexture.NONE -> Unit
            }
            onDrawBehind {
                when (texture) {
                    BgTexture.GRID -> drawPath(path, ink.copy(alpha = 0.05f), style = Stroke(1.dp.toPx()))
                    BgTexture.DIAGONAL -> drawPath(path, ink.copy(alpha = 0.045f), style = Stroke(1.dp.toPx()))
                    BgTexture.DOTS -> drawPoints(
                        dots, PointMode.Points, ink.copy(alpha = 0.09f),
                        strokeWidth = 2.4.dp.toPx(), cap = StrokeCap.Round
                    )
                    BgTexture.NONE -> Unit
                }
            }
        }
    )
}
