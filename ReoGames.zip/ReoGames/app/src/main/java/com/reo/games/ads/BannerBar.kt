package com.reo.games.ads

import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.reo.games.ui.theme.LocalReoColors

/**
 * true عندما يكون شريط الإعلان ظاهراً أسفل الشاشة.
 * حينها يتولى الشريط حشوة أزرار/شريط التنقل، فتتخلى الشاشات عن حشوتها السفلية لتجنّب فراغ مزدوج.
 */
val LocalBannerShown = compositionLocalOf { false }

/** هل يجب إظهار الشريط الآن؟ (شاشة مناسبة + إعلان محمّل فعلاً + لوحة المفاتيح مغلقة). */
@Composable
fun shouldShowBanner(ads: AdsManager, routeAllowsBanner: Boolean): Boolean {
    val state by ads.bannerState.collectAsState()
    val imeUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    return routeAllowsBanner && state == BannerState.LOADED && !imeUp
}

/**
 * شريط البانر: خط فاصل رفيع + إعلان 320×50 في المنتصف، فوق شريط التنقل مباشرة.
 * لا يُرسَم أصلاً قبل نجاح التحميل، فلا توجد حاوية فارغة أو مكسورة.
 */
@Composable
fun BannerSlot(ads: AdsManager) {
    val c = LocalReoColors.current
    val context = LocalContext.current
    val frame = remember { FrameLayout(context) }
    DisposableEffect(frame) {
        ads.attachTo(frame)
        onDispose { ads.detachFrom(frame) }
    }
    Column(Modifier.fillMaxWidth().background(c.bgBase).navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.outline))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            AndroidView(factory = { frame }, modifier = Modifier.size(320.dp, 50.dp))
        }
    }
}
