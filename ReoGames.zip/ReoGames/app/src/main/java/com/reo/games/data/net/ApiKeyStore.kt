package com.reo.games.data.net

import android.content.Context
import com.reo.games.BuildConfig

/**
 * مخزن مفتاح RAWG. الأولوية للمفتاح الذي يدخله المستخدم داخل التطبيق،
 * ثم المفتاح المحقون وقت البناء من local.properties (RAWG_API_KEY).
 * لا يوجد أي مفتاح مكتوب في الشيفرة المصدرية.
 */
class ApiKeyStore(context: Context) {
    private val prefs = context.getSharedPreferences("reo_secrets", Context.MODE_PRIVATE)

    fun get(): String =
        prefs.getString("rawg_key", null)?.trim().orEmpty().ifEmpty { BuildConfig.RAWG_API_KEY.trim() }

    fun hasKey(): Boolean = get().isNotEmpty()

    fun setUserKey(key: String) {
        prefs.edit().putString("rawg_key", key.trim()).apply()
    }

    fun userKey(): String = prefs.getString("rawg_key", "").orEmpty()
}
