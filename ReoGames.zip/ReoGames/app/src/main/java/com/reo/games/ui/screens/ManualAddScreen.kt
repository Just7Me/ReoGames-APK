package com.reo.games.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.reo.games.data.db.GameCategory
import com.reo.games.ui.AddGameViewModel
import com.reo.games.ui.components.CategoryPicker
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors

/** إضافة يدوية: عنوان + (سنة اختيارية) + صورة من معرض الهاتف. */
@Composable
fun ManualAddScreen(
    vm: AddGameViewModel,
    initialTitle: String,
    initialCategory: GameCategory,
    onBack: () -> Unit
) {
    val c = LocalReoColors.current
    var title by rememberSaveable { mutableStateOf(initialTitle) }
    var year by rememberSaveable { mutableStateOf("") }
    var coverUri by rememberSaveable { mutableStateOf<String?>(null) }
    var category by rememberSaveable { mutableStateOf(initialCategory) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) coverUri = uri.toString()
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = c.accent, unfocusedBorderColor = c.outline,
        focusedContainerColor = c.surface, unfocusedContainerColor = c.surface,
        cursorColor = c.accent, focusedTextColor = c.textPrimary, unfocusedTextColor = c.textPrimary
    )

    ReoScreen(title = "Add manually", onBack = onBack) {
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Use this when a game isn't in the online database.",
                color = c.textDim, fontSize = 13.sp
            )
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                label = { Text("Title") }, singleLine = true,
                colors = fieldColors, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = year, onValueChange = { v -> year = v.filter { it.isDigit() }.take(4) },
                label = { Text("Release year (optional)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = fieldColors, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Text("Cover image (optional)", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Box(
                Modifier
                    .width(150.dp)
                    .aspectRatio(2f / 3f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(c.surface)
                    .clickable {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                contentAlignment = Alignment.Center
            ) {
                val chosen = coverUri   // نسخة محلية: المتغير المفوَّض لا يدعم smart cast
                if (chosen != null) {
                    AsyncImage(
                        model = Uri.parse(chosen), contentDescription = "Cover",
                        contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Rounded.AddPhotoAlternate, null, tint = c.accent, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.height(6.dp))
                        Text("Choose image", color = c.textDim, fontSize = 13.sp)
                    }
                }
            }

            Text("Category", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            CategoryPicker(selected = category, onSelect = { category = it })
        }
        Box(Modifier.fillMaxWidth().background(c.surface.copy(alpha = 0.96f)).padding(16.dp)) {
            Button(
                // التكرار مرفوض في المستودع (بالعنوان)، فلا خطر من الضغط المزدوج
                onClick = { vm.addManual(title, year.toIntOrNull(), coverUri?.let { Uri.parse(it) }, category) },
                enabled = title.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text("Add Game to ${category.label}", fontSize = 15.sp, fontWeight = FontWeight.Bold) }
        }
    }
}
