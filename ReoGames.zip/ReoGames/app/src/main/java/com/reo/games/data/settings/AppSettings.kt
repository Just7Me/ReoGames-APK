package com.reo.games.data.settings

enum class BgType { DEFAULT, BLACK, NAVY, SOLID, GRADIENT, IMAGE }
enum class BgScale { COVER, FIT }
enum class BgTexture { NONE, GRID, DOTS, DIAGONAL }
enum class GradientDir { TOP_BOTTOM, BOTTOM_TOP, LEFT_RIGHT, RIGHT_LEFT, DIAG_DOWN, DIAG_UP }
enum class AspectMode(val label: String) {
    PORTRAIT("Portrait poster"), BOX("Box art"), SQUARE("Square"), AUTO("Auto")
}
enum class ThemePreset(val label: String) {
    BLUE_NEON("Blue Neon"), PURPLE_NEON("Purple Neon"), RED_GAMING("Red Gaming"),
    GREEN_GAMING("Green Gaming"), CYBERPUNK("Cyberpunk"), MONOCHROME("Monochrome"),
    MINIMAL_DARK("Minimal Dark"), CUSTOM("Custom")
}
enum class ThemeMode { DARK, LIGHT, SYSTEM }
enum class CategoryStyle { TEXT, PILL, UNDERLINE }
enum class SortOrder(val label: String) {
    TITLE_AZ("Title A–Z"), TITLE_ZA("Title Z–A"), RECENT("Recently added"),
    OLDEST("Oldest added"), RELEASE("Release date"), RATING("Personal rating"),
    PLAYTIME("Playtime")
}

/** كل الإعدادات القابلة للتخصيص. القيم الافتراضية = المظهر الداكن الافتراضي. */
data class AppSettings(
    // ---- الخلفية ----
    val bgType: BgType = BgType.DEFAULT,
    val bgSolid: Int = 0xFF0B1220.toInt(),
    val bgGradStart: Int = 0xFF0B1B3A.toInt(),
    val bgGradEnd: Int = 0xFF05070D.toInt(),
    val bgGradDir: GradientDir = GradientDir.TOP_BOTTOM,
    val bgImagePath: String = "",
    val bgBrightness: Float = 1f,   // 0.3 .. 1.5
    val bgDim: Float = 0.35f,       // 0 .. 0.85 (طبقة تعتيم للقراءة)
    val bgBlur: Float = 0f,         // 0 .. 25 dp
    val bgScale: BgScale = BgScale.COVER,
    val bgTexture: BgTexture = BgTexture.NONE,

    // ---- تخطيط المكتبة ----
    val columns: Int = 3,           // 2..5
    val coverScale: Float = 1f,     // 0.7 .. 1.0 (حجم الغلاف داخل الخلية)
    val aspect: AspectMode = AspectMode.PORTRAIT,
    val cornerRadius: Float = 14f,  // 0 .. 28 dp
    val cardBorder: Boolean = true,
    val cardShadow: Boolean = true,
    val cardGlow: Boolean = true,
    val cardOpacity: Float = 0.9f,  // 0.2 .. 1
    val compact: Boolean = false,
    val showTitle: Boolean = true,
    val showYear: Boolean = true,
    val titleLines: Int = 2,        // 1 أو 2
    val titleSize: Float = 12f,     // 9 .. 16 sp
    val titleCenter: Boolean = false,
    val hSpacing: Float = 10f,      // 0 .. 24 dp
    val vSpacing: Float = 14f,      // 0 .. 32 dp
    val titleGap: Float = 6f,       // 0 .. 14 dp

    // ---- الثيم ----
    val themePreset: ThemePreset = ThemePreset.BLUE_NEON,
    val customAccent: Int = 0xFF2F8CFF.toInt(),
    val themeMode: ThemeMode = ThemeMode.DARK,

    // ---- الشريط العلوي وشريط الفئات ----
    val showAppName: Boolean = true,
    val showCounts: Boolean = true,
    val toolbarCompact: Boolean = true,
    val categoryStyle: CategoryStyle = CategoryStyle.PILL,
    val categorySpacing: Float = 8f, // 0 .. 24 dp
    val showSearchShortcut: Boolean = true,
    val iconButtons: Boolean = true, // false = أزرار نصية لـ Add/Settings

    // ---- التفاعل ----
    val animations: Boolean = true,
    val pressAnimation: Boolean = true,
    val haptics: Boolean = true,
    val defaultSort: SortOrder = SortOrder.RECENT,
    val rememberCategory: Boolean = true,
    val lastCategory: String = "playing",
    val confirmRemove: Boolean = true,
    val showProgressPlaying: Boolean = true,
    val showCategoryBadge: Boolean = false
) {
    /** يعيد حقول المظهر إلى الافتراضي ويُبقي حقول التفاعل كما هي. */
    fun withDefaultAppearance(): AppSettings {
        val d = AppSettings()
        return d.copy(
            defaultSort = defaultSort,
            rememberCategory = rememberCategory,
            lastCategory = lastCategory,
            confirmRemove = confirmRemove,
            animations = animations,
            pressAnimation = pressAnimation,
            haptics = haptics,
            showProgressPlaying = showProgressPlaying,
            showCategoryBadge = showCategoryBadge
        )
    }
}
