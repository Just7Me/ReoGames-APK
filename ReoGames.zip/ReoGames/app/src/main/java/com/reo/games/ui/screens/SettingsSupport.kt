package com.reo.games.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.BuildConfig
import com.reo.games.SupportConfig
import com.reo.games.ads.AdsManager
import com.reo.games.ads.findActivity
import com.reo.games.ui.theme.LocalReoColors

/** بطاقة «❤️ Support the Developer» في الإعدادات: تفتح صفحة الدعم. */
@Composable
fun SupportEntryCard(onClick: () -> Unit) {
    val c = LocalReoColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(c.surface.copy(alpha = 0.92f))
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("❤️", fontSize = 24.sp, modifier = Modifier.padding(end = 12.dp))
        Column(Modifier.weight(1f)) {
            Text("Support the Developer", color = c.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("Optional — the app stays fully free to use", color = c.textDim, fontSize = 12.sp)
        }
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, tint = c.textDim)
    }
}

/** الإعلانات والخصوصية: شرح بسيط، وزر خيارات الخصوصية عند إلزامه قانونياً، ورابط سياسة الخصوصية إن ضُبط. */
@Composable
fun AdsPrivacySection(ads: AdsManager) {
    val c = LocalReoColors.current
    val context = LocalContext.current
    val privacyRequired by ads.privacyOptionsRequired.collectAsState()
    val adStatus by ads.adStatus.collectAsState()
    val policyUrl = SupportConfig.privacyPolicyUrl

    SettingsSection("Ads & privacy") {
        Text(
            "A small banner ad appears at the bottom of the main screens. It never covers your games, " +
                "and the app works exactly the same if it can't load.",
            color = c.textDim, fontSize = 13.sp, lineHeight = 19.sp
        )
        if (BuildConfig.ADS_TEST_MODE) {
            Text("This build shows Google test ads only.", color = c.textDim, fontSize = 12.sp)
        }
        // حالة الإعلان الحالية (للتشخيص: محمّل / لا إعلان متاح / معرّف خاطئ …)
        Text("Ad status: $adStatus", color = c.textDim, fontSize = 12.sp, lineHeight = 17.sp)
        if (privacyRequired) {
            OutlinedButton(
                onClick = { context.findActivity()?.let { ads.showPrivacyOptions(it) } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Privacy choices (ads)") }
        }
        if (policyUrl != null) {
            OutlinedButton(
                onClick = { openLink(context, policyUrl) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Privacy policy") }
        }
    }
}
