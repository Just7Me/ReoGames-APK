package com.reo.games

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.reo.games.ads.AdsManager
import com.reo.games.ui.AddGameViewModel
import com.reo.games.ui.AppNav
import com.reo.games.ui.MainViewModel
import com.reo.games.ui.ReoViewModelFactory
import com.reo.games.ui.theme.ReoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as ReoApp).container
        val factory = ReoViewModelFactory(container)
        ads = container.ads
        // موافقة المستخدم (إن لزمت) ثم تهيئة SDK وتحميل البانر؛ لا يحجب هذا واجهة التطبيق
        ads.start(this)

        setContent {
            val vm: MainViewModel = viewModel(factory = factory)
            val addVm: AddGameViewModel = viewModel(factory = factory)
            val settings by vm.settings.collectAsState()
            val ready by vm.ready.collectAsState()
            val s = settings

            if (s == null || !ready) {
                // لحظة تحميل قصيرة جداً: نتجنب وميض الإعدادات الافتراضية قبل قراءة المحفوظة
                Box(Modifier.fillMaxSize().background(Color(0xFF05070D)))
            } else {
                ReoTheme(s) {
                    AppNav(vm, addVm, s, ads)
                }
            }
        }
    }

    private lateinit var ads: AdsManager

    override fun onResume() {
        super.onResume()
        ads.resume()
    }

    override fun onPause() {
        ads.pause()
        super.onPause()
    }

    override fun onDestroy() {
        ads.release(this)
        super.onDestroy()
    }
}
