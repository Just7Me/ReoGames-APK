package com.reo.games.data

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.reo.games.data.db.GameCategory
import com.reo.games.data.db.GameDao
import com.reo.games.data.db.GameEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class ImportMode { MERGE, REPLACE }

data class ImportReport(
    val added: Int = 0,
    val skippedDuplicates: Int = 0,
    val error: String? = null
)

/**
 * نسخ احتياطي بصيغة JSON.
 * - يشمل: كل بيانات اللعبة والتتبع الشخصي (فئة، وقت لعب، تقدم، تقييم، ملاحظات، تواريخ).
 * - صور الأغلفة: ألعاب RAWG تُحفظ كروابط فقط (تُنزَّل مجدداً عند الاستعادة مع اتصال).
 *   أما الألعاب المضافة يدوياً فتُضمَّن صورتها (مصغّرة) داخل الملف بصيغة Base64.
 */
class BackupManager(
    private val context: Context,
    private val repo: GameRepository,
    private val dao: GameDao
) {
    suspend fun buildJson(): String = withContext(Dispatchers.IO) {
        val games = JSONArray()
        for (g in dao.getAll()) {
            val o = JSONObject()
            o.put("rawgId", g.rawgId ?: JSONObject.NULL)
            o.put("title", g.title)
            o.put("coverUrl", g.coverUrl ?: JSONObject.NULL)
            o.put("description", g.description ?: JSONObject.NULL)
            o.put("releaseDate", g.releaseDate ?: JSONObject.NULL)
            o.put("releaseYear", g.releaseYear ?: JSONObject.NULL)
            o.put("developers", g.developers ?: JSONObject.NULL)
            o.put("publishers", g.publishers ?: JSONObject.NULL)
            o.put("platforms", g.platforms ?: JSONObject.NULL)
            o.put("genres", g.genres ?: JSONObject.NULL)
            o.put("rating", g.rating ?: JSONObject.NULL)
            o.put("website", g.website ?: JSONObject.NULL)
            o.put("category", g.category)
            o.put("playtimeHours", g.playtimeHours ?: JSONObject.NULL)
            o.put("progress", g.progress ?: JSONObject.NULL)
            o.put("personalRating", g.personalRating ?: JSONObject.NULL)
            o.put("notes", g.notes ?: JSONObject.NULL)
            o.put("dateAdded", g.dateAdded)
            o.put("dateCompleted", g.dateCompleted ?: JSONObject.NULL)
            if (g.rawgId == null && g.localCoverPath != null) {
                val f = File(g.localCoverPath)
                if (f.exists() && f.length() < 3_000_000) {
                    o.put("coverBase64", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP))
                }
            }
            games.put(o)
        }
        JSONObject().apply {
            put("app", "reo_games")
            put("version", 1)
            put("exportedAt", System.currentTimeMillis())
            put("games", games)
        }.toString(2)
    }

    suspend fun exportTo(uri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val text = buildJson()
            context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) }
                ?: error("Couldn't open the destination file")
            JSONObject(text).getJSONArray("games").length()
        }
    }

    /** يقرأ الملف ويتحقق منه كاملاً قبل أي تعديل على المكتبة. */
    private fun parse(text: String): List<Pair<GameEntity, String?>> {
        val root = JSONObject(text)
        require(root.optString("app") == "reo_games") { "This isn't a Reo Games backup file" }
        val arr = root.getJSONArray("games")
        val out = ArrayList<Pair<GameEntity, String?>>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val title = o.optString("title").trim()
            require(title.isNotEmpty()) { "Entry ${i + 1} has no title" }
            fun s(k: String) = if (o.isNull(k)) null else o.optString(k).ifEmpty { null }
            fun n(k: String) = !o.isNull(k) && o.has(k)
            out += GameEntity(
                rawgId = if (n("rawgId")) o.optInt("rawgId") else null,
                title = title,
                coverUrl = s("coverUrl"),
                description = s("description"),
                releaseDate = s("releaseDate"),
                releaseYear = if (n("releaseYear")) o.optInt("releaseYear") else null,
                developers = s("developers"),
                publishers = s("publishers"),
                platforms = s("platforms"),
                genres = s("genres"),
                rating = if (n("rating")) o.optDouble("rating") else null,
                website = s("website"),
                category = GameCategory.fromKey(s("category")).key,
                playtimeHours = if (n("playtimeHours")) o.optDouble("playtimeHours") else null,
                progress = if (n("progress")) o.optInt("progress") else null,
                personalRating = if (n("personalRating")) o.optInt("personalRating") else null,
                notes = s("notes"),
                dateAdded = o.optLong("dateAdded", System.currentTimeMillis()),
                dateCompleted = if (n("dateCompleted")) o.optLong("dateCompleted") else null
            ) to s("coverBase64")
        }
        return out
    }

    suspend fun importFrom(uri: Uri, mode: ImportMode): ImportReport = withContext(Dispatchers.IO) {
        val entries = try {
            val text = context.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
                ?: return@withContext ImportReport(error = "Couldn't open the file")
            parse(text)
        } catch (e: Exception) {
            return@withContext ImportReport(error = e.message ?: "The file couldn't be read")
        }

        if (mode == ImportMode.REPLACE) {
            dao.getAll().forEach { g -> g.localCoverPath?.let { runCatching { File(it).delete() } } }
            dao.deleteAll()
        }

        var added = 0
        var skipped = 0
        for ((game, b64) in entries) {
            if (repo.findDuplicate(game.rawgId, game.title) != null) { skipped++; continue }
            val id = dao.insert(game.copy(id = 0, sortIndex = game.dateAdded))
            if (id == -1L) { skipped++; continue }
            added++
            if (b64 != null) {
                runCatching {
                    val f = File(ImageStore.coversDir(context), "manual_$id.jpg")
                    f.writeBytes(Base64.decode(b64, Base64.NO_WRAP))
                    dao.getById(id)?.let { dao.update(it.copy(localCoverPath = f.absolutePath)) }
                }
            } else {
                repo.cacheCoverInBackground(id, game)
            }
        }
        ImportReport(added = added, skippedDuplicates = skipped)
    }
}
