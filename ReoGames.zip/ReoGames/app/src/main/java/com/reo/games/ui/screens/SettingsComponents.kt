package com.reo.games.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reo.games.ui.theme.LocalReoColors

@Composable
fun SettingsSection(title: String, content: @Composable () -> Unit) {
    val c = LocalReoColors.current
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            title.uppercase(), color = c.accent, fontSize = 12.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 4.dp)
        )
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(c.surface.copy(alpha = 0.92f)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) { content() }
    }
}

@Composable
fun SubTitle(text: String) {
    val c = LocalReoColors.current
    Text(text, color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun SwitchRow(label: String, checked: Boolean, hint: String? = null, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val c = LocalReoColors.current
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = if (enabled) c.textPrimary else c.textDim, fontSize = 15.sp)
            if (hint != null) Text(hint, color = c.textDim, fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedThumbColor = c.onAccent, checkedTrackColor = c.accent)
        )
    }
}

@Composable
fun SliderRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    steps: Int = 0,
    onChange: (Float) -> Unit
) {
    val c = LocalReoColors.current
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = c.textPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = c.textDim, fontSize = 13.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = c.accent, activeTrackColor = c.accent, inactiveTrackColor = c.outline,
                activeTickColor = c.onAccent.copy(alpha = 0.5f), inactiveTickColor = c.textDim.copy(alpha = 0.4f)
            )
        )
    }
}

/** مجموعة خيارات متنافية (مقسّمة عبر عدة أسطر عند الحاجة). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChoiceChips(
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    val c = LocalReoColors.current
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            val on = value == selected
            val shape = RoundedCornerShape(12.dp)
            Text(
                label,
                color = if (on) c.onAccent else c.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier
                    .clip(shape)
                    .background(if (on) c.accent else c.surfaceHigh)
                    .border(1.dp, if (on) c.accent else c.outline, shape)
                    .clickable { onSelect(value) }
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
fun ColorSwatch(color: Color, selected: Boolean, size: Int = 36, onClick: () -> Unit) {
    val c = LocalReoColors.current
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(color)
            .border(if (selected) 3.dp else 1.dp, if (selected) c.textPrimary else c.outline, CircleShape)
            .clickable(onClick = onClick)
    )
}

/** يظهر عنصر لون مع زر لفتح منتقي الألوان. */
@Composable
fun ColorRow(label: String, color: Int, onPick: (Int) -> Unit) {
    val c = LocalReoColors.current
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable { open = true }.padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = c.textPrimary, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text("#%06X".format(color and 0xFFFFFF), color = c.textDim, fontSize = 12.sp)
        Spacer(Modifier.width(10.dp))
        ColorSwatch(Color(color), selected = false, size = 30) { open = true }
    }
    if (open) ColorPickerDialog(initial = color, onDismiss = { open = false }, onPick = { onPick(it); open = false })
}

/** منتقي ألوان HSV كامل + إدخال HEX. */
@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val c = LocalReoColors.current
    val hsv = remember(initial) {
        FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) }
    }
    var hue by remember { mutableStateOf(hsv[0]) }
    var sat by remember { mutableStateOf(hsv[1]) }
    var value by remember { mutableStateOf(hsv[2]) }
    val current = Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
    var hex by remember { mutableStateOf("%06X".format(initial and 0xFFFFFF)) }
    var hexError by remember { mutableStateOf(false) }

    // يُحسب من القيم الحالية مباشرة (وليس من `current` المحسوبة أثناء التركيب) كي لا يتأخر الـ HEX خطوة
    fun syncHex() {
        val fresh = Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
        hex = "%06X".format(fresh.toArgb() and 0xFFFFFF)
        hexError = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pick a color") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(12.dp)).background(current).border(1.dp, c.outline, RoundedCornerShape(12.dp)))
                Text("Hue", fontSize = 12.sp, color = c.textDim)
                Slider(
                    value = hue, onValueChange = { hue = it; syncHex() }, valueRange = 0f..360f,
                    colors = SliderDefaults.colors(thumbColor = Color.hsv(hue.coerceIn(0f, 360f), 1f, 1f), activeTrackColor = Color.hsv(hue.coerceIn(0f, 360f), 1f, 1f))
                )
                Text("Saturation", fontSize = 12.sp, color = c.textDim)
                Slider(value = sat, onValueChange = { sat = it; syncHex() }, valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent))
                Text("Brightness", fontSize = 12.sp, color = c.textDim)
                Slider(value = value, onValueChange = { value = it; syncHex() }, valueRange = 0f..1f,
                    colors = SliderDefaults.colors(thumbColor = c.accent, activeTrackColor = c.accent))
                OutlinedTextField(
                    value = hex,
                    onValueChange = { t ->
                        val clean = t.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                        hex = clean
                        if (clean.length == 6) {
                            val argb = (0xFF000000L or clean.toLong(16)).toInt()
                            val tmp = FloatArray(3)
                            android.graphics.Color.colorToHSV(argb, tmp)
                            hue = tmp[0]; sat = tmp[1]; value = tmp[2]
                            hexError = false
                        } else hexError = true
                    },
                    prefix = { Text("#") },
                    label = { Text("HEX") }, singleLine = true, isError = hexError,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = c.accent, unfocusedBorderColor = c.outline,
                        cursorColor = c.accent, focusedTextColor = c.textPrimary, unfocusedTextColor = c.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(enabled = !hexError, onClick = { onPick(current.toArgb()) }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
