import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.devtools.ksp")
}

// مفتاح RAWG يُقرأ من local.properties (غير مُدرج في Git) أو من متغير بيئة
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
val rawgKey: String = localProps.getProperty("RAWG_API_KEY")
    ?: System.getenv("RAWG_API_KEY")
    ?: ""

// ---------------------------------------------------------------------------
// إعدادات اختيارية (إعلانات AdMob + صفحة دعم المطوّر). الأولوية: متغير بيئة ثم local.properties.
// القيمة الفارغة = غير مضبوطة. التفاصيل الكاملة في README.md (قسم «الإعلانات والدعم»).
// ---------------------------------------------------------------------------
fun cfg(key: String): String =
    (System.getenv(key)?.trim()?.takeIf { it.isNotEmpty() }
        ?: localProps.getProperty(key)?.trim()?.takeIf { it.isNotEmpty() }
        ?: "")

// معرّفات Google الرسمية للإعلانات التجريبية (آمنة للاختبار، لا تُحتسب ولا تُدفع).
val testAdmobAppId = "ca-app-pub-3940256099942544~3347511713"
val testBannerUnitId = "ca-app-pub-3940256099942544/6300978111"

// معرّفاتك الحقيقية (تُستخدم في نسخة release فقط، ولا بد من وجودها كلتيهما وبصيغة صحيحة).
val prodAdmobAppId = cfg("ADMOB_APP_ID")
val prodBannerUnitId = cfg("ADMOB_BANNER_UNIT_ID")
val prodAdsValid = Regex("""ca-app-pub-\d{10,20}~\d{5,15}""").matches(prodAdmobAppId) &&
    Regex("""ca-app-pub-\d{10,20}/\d{5,15}""").matches(prodBannerUnitId)
if ((prodAdmobAppId.isNotEmpty() || prodBannerUnitId.isNotEmpty()) && !prodAdsValid) {
    logger.warn("ADMOB_APP_ID / ADMOB_BANNER_UNIT_ID are missing or malformed: release builds will use Google TEST ads.")
}

// روابط خارجية: لا تُقبل إلا https وبلا مسافات أو علامات اقتباس (وإلا تُعدّ غير مضبوطة).
fun cfgUrl(key: String): String {
    val v = cfg(key)
    return if (v.isEmpty()) "" else if (Regex("""https://[^\s"\\]+""").matches(v)) v else {
        logger.warn("$key is ignored: it must start with https:// and contain no spaces or quotes.")
        ""
    }
}
val donationUrl = cfgUrl("DONATION_URL")
val githubUrl = cfgUrl("PROJECT_GITHUB_URL")
val privacyPolicyUrl = cfgUrl("PRIVACY_POLICY_URL")

android {
    namespace = "com.reo.games"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.reo.games"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "RAWG_API_KEY", "\"$rawgKey\"")
        buildConfigField("String", "DONATION_URL", "\"$donationUrl\"")
        buildConfigField("String", "GITHUB_URL", "\"$githubUrl\"")
        buildConfigField("String", "PRIVACY_POLICY_URL", "\"$privacyPolicyUrl\"")
    }

    // توقيع نسخة release: يُفعَّل فقط حين تتوفر المتغيرات الأربعة (يحقنها workflow «Build signed release APK»).
    // لا تضع كلمات السر في الشيفرة أبداً.
    val ksFile = System.getenv("RELEASE_KEYSTORE_FILE")?.trim().orEmpty()
    val ksPass = System.getenv("RELEASE_KEYSTORE_PASSWORD").orEmpty()
    val ksAlias = System.getenv("RELEASE_KEY_ALIAS")?.trim().orEmpty()
    val ksKeyPass = System.getenv("RELEASE_KEY_PASSWORD").orEmpty()
    val canSignRelease = ksFile.isNotEmpty() && file(ksFile).exists() &&
        ksPass.isNotEmpty() && ksAlias.isNotEmpty() && ksKeyPass.isNotEmpty()
    if (canSignRelease) {
        signingConfigs {
            create("release") {
                storeFile = file(ksFile)
                storePassword = ksPass
                keyAlias = ksAlias
                keyPassword = ksKeyPass
            }
        }
    }

    buildTypes {
        // نسخة التطوير/الاختبار: إعلانات Google التجريبية دائماً، مهما كانت معرّفاتك الحقيقية.
        debug {
            manifestPlaceholders["admobAppId"] = testAdmobAppId
            buildConfigField("String", "ADMOB_BANNER_UNIT_ID", "\"$testBannerUnitId\"")
            buildConfigField("boolean", "ADS_TEST_MODE", "true")
        }
        release {
            if (canSignRelease) signingConfig = signingConfigs.getByName("release")
            // إعلانات حقيقية فقط إن ضبطتَ المعرّفين الحقيقيين بصيغة صحيحة؛ وإلا تبقى تجريبية.
            manifestPlaceholders["admobAppId"] = if (prodAdsValid) prodAdmobAppId else testAdmobAppId
            buildConfigField(
                "String", "ADMOB_BANNER_UNIT_ID",
                "\"${if (prodAdsValid) prodBannerUnitId else testBannerUnitId}\""
            )
            buildConfigField("boolean", "ADS_TEST_MODE", if (prodAdsValid) "false" else "true")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.navigation:navigation-compose:2.8.0")

    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // DataStore
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // الشبكة
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.retrofit2:converter-kotlinx-serialization:2.11.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // الصور
    implementation("io.coil-kt:coil-compose:2.7.0")

    // الإعلانات: بانر AdMob + نافذة الموافقة (UMP) المطلوبة في الاتحاد الأوروبي/بريطانيا
    implementation("com.google.android.gms:play-services-ads:23.3.0")
    implementation("com.google.android.ump:user-messaging-platform:3.0.0")
}
