package com.reo.games.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.reo.games.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

enum class BannerState { IDLE, LOADING, LOADED, FAILED }

/**
 * مسؤول وحيد عن الإعلانات: موافقة المستخدم (UMP) ← تهيئة SDK مرة واحدة ← بانر واحد صغير (320×50).
 *
 * قواعد:
 *  - لا يُطلب أي إعلان قبل `canRequestAds()` (يحترم موافقة الاتحاد الأوروبي/بريطانيا).
 *  - AdView واحد فقط يُعاد استخدامه بين الشاشات، فلا إعادة تحميل عند التنقل.
 *  - لا نستدعي loadAd يدوياً بعد النجاح: التحديث الدوري يديره AdMob نفسه (اضبطه ≥ 60 ثانية في لوحة AdMob).
 *  - عند الفشل: على الأكثر محاولتان إضافيتان بفاصل 60 ثم 180 ثانية، وبعدها نتوقف. التطبيق يعمل دائماً بلا إعلان.
 *  - المعرّفات تأتي من BuildConfig (تجريبية في debug دائماً — انظر app/build.gradle.kts).
 */
class AdsManager(private val app: android.app.Application) {

    private val _bannerState = MutableStateFlow(BannerState.IDLE)
    val bannerState: StateFlow<BannerState> = _bannerState.asStateFlow()

    private val _privacyOptionsRequired = MutableStateFlow(false)
    /** true عندما يوجب القانون (EEA/UK…) إتاحة زر «خيارات الخصوصية» للمستخدم. */
    val privacyOptionsRequired: StateFlow<Boolean> = _privacyOptionsRequired.asStateFlow()

    private val main = Handler(Looper.getMainLooper())
    private val sdkInitStarted = AtomicBoolean(false)
    private var sdkReady = false
    private var consentInFlight = false
    private var activityRef: WeakReference<Activity>? = null

    private var banner: AdView? = null
    private var everLoaded = false
    private var retries = 0

    /** يُستدعى من MainActivity.onCreate. آمن لتكراره (مثلاً بعد إعادة إنشاء النشاط). */
    fun start(activity: Activity) {
        activityRef = WeakReference(activity)
        if (sdkReady) {
            loadBannerIfNeeded(activity)
            return
        }
        if (consentInFlight) return

        val info = UserMessagingPlatform.getConsentInformation(activity)
        consentInFlight = true
        info.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                // نجح تحديث حالة الموافقة: تُعرض النافذة فقط إن كانت مطلوبة قانونياً
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    consentInFlight = false
                    onConsentResolved(info)
                }
            },
            {
                // فشل الاتصال بخدمة الموافقة: نعتمد على آخر حالة محفوظة (canRequestAds)
                consentInFlight = false
                onConsentResolved(info)
            }
        )
        // مستخدم وافق سابقاً: لا داعي لانتظار الشبكة
        if (info.canRequestAds()) initializeSdk()
    }

    private fun onConsentResolved(info: ConsentInformation) {
        _privacyOptionsRequired.value =
            info.privacyOptionsRequirementStatus == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED
        if (info.canRequestAds()) initializeSdk()
    }

    /** زر «Privacy choices» في الإعدادات (يظهر فقط عند الإلزام). */
    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) {
            val info = UserMessagingPlatform.getConsentInformation(activity)
            onConsentResolved(info)
        }
    }

    private fun initializeSdk() {
        if (!sdkInitStarted.compareAndSet(false, true)) return
        // التهيئة خارج الخيط الرئيسي كما توصي Google لتفادي تأخير بدء التطبيق
        Thread {
            MobileAds.initialize(app) {
                main.post {
                    sdkReady = true
                    activityRef?.get()?.let { loadBannerIfNeeded(it) }
                }
            }
        }.start()
    }

    private fun loadBannerIfNeeded(activity: Activity) {
        if (banner != null || !sdkReady) return
        val view = AdView(activity).apply {
            setAdSize(AdSize.BANNER) // 320×50: البانر القياسي الصغير
            adUnitId = BuildConfig.ADMOB_BANNER_UNIT_ID
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    everLoaded = true
                    retries = 0
                    _bannerState.value = BannerState.LOADED
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    // فشل تحديث دوري بينما إعلان سليم معروض: نُبقيه كما هو
                    if (everLoaded) return
                    _bannerState.value = BannerState.FAILED
                    scheduleRetry()
                }
            }
        }
        banner = view
        _bannerState.value = BannerState.LOADING
        view.loadAd(AdRequest.Builder().build())
    }

    private val retryTask = Runnable {
        val view = banner ?: return@Runnable
        if (_bannerState.value == BannerState.FAILED) {
            _bannerState.value = BannerState.LOADING
            view.loadAd(AdRequest.Builder().build())
        }
    }

    private fun scheduleRetry() {
        if (retries >= RETRY_DELAYS_MS.size) return // نتوقف: لا إغراق للخادم
        main.postDelayed(retryTask, RETRY_DELAYS_MS[retries])
        retries++
    }

    /** يضع AdView داخل الحاوية (ينتزعه من حاويته السابقة أولاً). */
    fun attachTo(frame: FrameLayout) {
        val view = banner ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        frame.addView(
            view,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )
    }

    fun detachFrom(frame: FrameLayout) = frame.removeAllViews()

    fun pause() { banner?.pause() }
    fun resume() { banner?.resume() }

    /**
     * عند تدمير النشاط: AdView مرتبط بسياقه فيُحرَّر، ويُعاد إنشاؤه من النشاط الجديد إن وُجد.
     * نتحقق من النشاط حتى لا يلغي onDestroy قديم متأخر عمل نشاط جديد بدأ للتو.
     */
    fun release(activity: Activity) {
        if (banner?.context === activity) {
            main.removeCallbacks(retryTask)
            banner?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
            banner = null
            everLoaded = false
            retries = 0
            _bannerState.value = BannerState.IDLE
        }
        val current = activityRef?.get()
        if (current === activity) activityRef = null
        else current?.let { loadBannerIfNeeded(it) }
    }

    private companion object {
        val RETRY_DELAYS_MS = longArrayOf(60_000L, 180_000L)
    }
}

/** يجد النشاط خلف ContextWrapper (لازم لنوافذ الموافقة). */
fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
