package com.reo.games.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.reo.games.data.net.RawgGameSummary
import com.reo.games.ui.AddGameViewModel
import com.reo.games.ui.SearchError
import com.reo.games.ui.components.ReoScreen
import com.reo.games.ui.theme.LocalReoColors

@Composable
fun AddGameScreen(
    vm: AddGameViewModel,
    libraryRawgIds: Set<Int>,
    savedKey: String,
    onSaveKey: (String) -> Unit,
    onBack: () -> Unit,
    onPick: (RawgGameSummary) -> Unit,
    onManual: (String) -> Unit
) {
    val c = LocalReoColors.current
    val st by vm.search.collectAsState()
    val focus = LocalFocusManager.current
    val requester = remember { FocusRequester() }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) { runCatching { requester.requestFocus() } }

    // تحميل المزيد تلقائياً عند الاقتراب من نهاية القائمة
    LaunchedEffect(listState, st.results.size) {
        snapshotFlow {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= listState.layoutInfo.totalItemsCount - 4
        }.collect { nearEnd -> if (nearEnd) vm.loadMore() }
    }

    ReoScreen(title = "Add Game", onBack = onBack) {
        OutlinedTextField(
            value = st.query,
            onValueChange = vm::onQueryChange,
            singleLine = true,
            placeholder = { Text("Search any game — e.g. Elden Ring", color = c.textDim) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = c.textDim) },
            trailingIcon = {
                if (st.query.isNotEmpty()) {
                    IconButton(onClick = { vm.onQueryChange("") }) {
                        Icon(Icons.Rounded.Clear, "Clear", tint = c.textDim)
                    }
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus(); vm.retry() }),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = c.accent,
                unfocusedBorderColor = c.outline,
                focusedContainerColor = c.surface,
                unfocusedContainerColor = c.surface,
                cursorColor = c.accent,
                focusedTextColor = c.textPrimary,
                unfocusedTextColor = c.textPrimary
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).focusRequester(requester)
        )
        Spacer(Modifier.height(6.dp))
        if (st.loading) LinearProgressIndicator(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(2.dp),
            color = c.accent, trackColor = c.outline
        ) else Spacer(Modifier.height(2.dp))

        when {
            st.error != null -> ErrorPane(
                error = st.error!!,
                savedKey = savedKey,
                onSaveKey = { onSaveKey(it); vm.retry() },
                onRetry = vm::retry,
                onManual = { onManual(st.query.trim()) },
                canManual = st.query.isNotBlank()
            )
            st.query.isBlank() -> HintPane()
            st.searched && st.results.isEmpty() && !st.loading -> NoResultsPane(
                query = st.query.trim(),
                onManual = { onManual(st.query.trim()) }
            )
            else -> LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(st.results, key = { it.id }) { game ->
                    ResultRow(game, inLibrary = game.id in libraryRawgIds) {
                        focus.clearFocus()
                        onPick(game)
                    }
                }
                item(key = "footer") {
                    Box(Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        when {
                            st.loadingMore -> CircularProgressIndicator(
                                modifier = Modifier.size(24.dp), strokeWidth = 2.5.dp, color = c.accent
                            )
                            st.hasMore -> OutlinedButton(onClick = vm::loadMore) { Text("Load more") }
                            st.results.isNotEmpty() -> TextButtonManual(st.query.trim(), onManual)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TextButtonManual(query: String, onManual: (String) -> Unit) {
    val c = LocalReoColors.current
    Text(
        "Can't find it? Add \"$query\" manually",
        color = c.accent,
        fontSize = 13.sp,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { onManual(query) }.padding(8.dp)
    )
}

@Composable
private fun ResultRow(game: RawgGameSummary, inLibrary: Boolean, onClick: () -> Unit) {
    val c = LocalReoColors.current
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.surface.copy(alpha = 0.92f))
            .clickable(onClick = onClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.width(62.dp).height(84.dp).clip(RoundedCornerShape(10.dp)).background(c.surfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.SportsEsports, null, tint = c.textDim.copy(alpha = 0.5f), modifier = Modifier.size(26.dp))
            if (game.backgroundImage != null) {
                AsyncImage(
                    model = game.backgroundImage,
                    contentDescription = game.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                game.name.orEmpty(),
                color = c.textPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val meta = buildList {
                game.year?.let { add(it.toString()) }
                game.rating?.takeIf { it > 0 }?.let { add("★ %.1f".format(it)) }
            }.joinToString("  ·  ")
            if (meta.isNotEmpty()) Text(meta, color = c.textDim, fontSize = 12.5.sp)
            val plats = game.platformNames
            if (plats.isNotEmpty()) {
                val shown = plats.take(3).joinToString(", ")
                Text(
                    if (plats.size > 3) "$shown +${plats.size - 3}" else shown,
                    color = c.textDim,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (inLibrary) {
                Text(
                    "In your library",
                    color = c.accent,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun HintPane() {
    val c = LocalReoColors.current
    CenterPane(Icons.Rounded.Search, "Find any game", "Start typing a title. Results show up as you type, with cover art and details.")
}

@Composable
private fun NoResultsPane(query: String, onManual: () -> Unit) {
    CenterPane(
        icon = Icons.Rounded.SearchOff,
        title = "No results for \"$query\"",
        body = "Check the spelling, or add it yourself with a title and a picture from your phone."
    ) {
        Button(onClick = onManual) {
            Icon(Icons.Rounded.Edit, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Add manually")
        }
    }
}

@Composable
private fun ErrorPane(
    error: SearchError,
    savedKey: String,
    onSaveKey: (String) -> Unit,
    onRetry: () -> Unit,
    onManual: () -> Unit,
    canManual: Boolean
) {
    when (error) {
        SearchError.NoKey -> KeyPane(savedKey, onSaveKey)
        SearchError.Offline -> CenterPane(
            Icons.Rounded.CloudOff, "You're offline",
            "Searching needs an internet connection. Your library still works offline."
        ) {
            Button(onClick = onRetry) { Text("Try again") }
            if (canManual) OutlinedButton(onClick = onManual) { Text("Add manually") }
        }
        is SearchError.Message -> CenterPane(Icons.Rounded.Warning, "Search failed", error.text) {
            Button(onClick = onRetry) { Text("Try again") }
            if (canManual) OutlinedButton(onClick = onManual) { Text("Add manually") }
        }
    }
}

@Composable
private fun KeyPane(savedKey: String, onSave: (String) -> Unit) {
    val c = LocalReoColors.current
    var text by remember { mutableStateOf(savedKey) }
    CenterPane(
        icon = Icons.Rounded.Key,
        title = "RAWG API key needed",
        body = "Online search uses the free RAWG database. Get a free key at rawg.io/apidocs and paste it here. " +
            "It's stored only on this phone."
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            label = { Text("API key") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = c.accent, unfocusedBorderColor = c.outline,
                cursorColor = c.accent, focusedTextColor = c.textPrimary, unfocusedTextColor = c.textPrimary
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { onSave(text) }, enabled = text.isNotBlank()) { Text("Save key") }
    }
}

@Composable
private fun CenterPane(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    actions: @Composable ColumnScope.() -> Unit = {}
) {
    val c = LocalReoColors.current
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically)
    ) {
        Icon(icon, null, tint = c.accent, modifier = Modifier.size(44.dp))
        Text(title, color = c.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(body, color = c.textDim, fontSize = 14.sp, textAlign = TextAlign.Center)
        actions()
    }
}
