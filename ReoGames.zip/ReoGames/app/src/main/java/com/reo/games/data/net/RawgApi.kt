package com.reo.games.data.net

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface RawgApi {
    @GET("games")
    suspend fun search(
        @Query("key") key: String,
        @Query("search") query: String,
        @Query("page") page: Int,
        @Query("page_size") pageSize: Int = 20,
        @Query("search_precise") precise: Boolean = false
    ): RawgSearchResponse

    @GET("games/{id}")
    suspend fun details(
        @Path("id") id: Int,
        @Query("key") key: String
    ): RawgGameDetail
}
